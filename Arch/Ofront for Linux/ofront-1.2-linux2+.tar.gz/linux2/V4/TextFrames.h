/* Ofront 1.2 -xtspka */

#ifndef TextFrames__h
#define TextFrames__h

#include "SYSTEM.h"
#include "Display.h"
#include "Fonts.h"
#include "Texts.h"

typedef
	struct TextFrames_DisplayMsg { /* Texts_ElemMsg */
		BOOLEAN prepare;
		Fonts_Font fnt;
		SHORTINT col;
		LONGINT pos;
		Display_Frame frame;
		INTEGER X0, Y0;
		LONGINT indent;
		Display_Frame elemFrame;
	} TextFrames_DisplayMsg;

typedef
	struct TextFrames_FocusMsg { /* Texts_ElemMsg */
		BOOLEAN focus;
		Display_Frame elemFrame, frame;
	} TextFrames_FocusMsg;

typedef
	struct TextFrames_FrameDesc *TextFrames_Frame;

typedef
	struct TextFrames_Location {
		LONGINT org, pos;
		INTEGER x, y, dx, dy;
		char _prvt0[4];
	} TextFrames_Location;

typedef
	struct TextFrames_FrameDesc { /* Display_FrameDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		Texts_Text text;
		LONGINT org;
		INTEGER col, left, right, top, bot, markH, barW;
		LONGINT time;
		BOOLEAN hasCar, hasSel, showsParcs;
		TextFrames_Location carloc, selbeg, selend;
		Display_Frame focus;
		char _prvt0[4];
	} TextFrames_FrameDesc;

typedef
	struct TextFrames_InsertElemMsg { /* Display_FrameMsg */
		Texts_Elem e;
	} TextFrames_InsertElemMsg;

typedef
	struct TextFrames_NotifyMsg { /* Display_FrameMsg */
		Display_Frame frame;
	} TextFrames_NotifyMsg;

typedef
	struct TextFrames_ParcDesc *TextFrames_Parc;

typedef
	struct TextFrames_ParcDesc { /* Texts_ElemDesc */
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
		LONGINT left, first, width, lead, lsp, dsr;
		SET opts;
		INTEGER nofTabs;
		LONGINT tab[32];
	} TextFrames_ParcDesc;

typedef
	struct TextFrames_TrackMsg { /* Texts_ElemMsg */
		INTEGER X, Y;
		SET keys;
		Fonts_Font fnt;
		SHORTINT col;
		LONGINT pos;
		Display_Frame frame;
		INTEGER X0, Y0;
	} TextFrames_TrackMsg;

typedef
	struct TextFrames_UpdateMsg { /* Display_FrameMsg */
		INTEGER id;
		Texts_Text text;
		LONGINT beg, end;
	} TextFrames_UpdateMsg;


import INTEGER TextFrames_menuH, TextFrames_barW, TextFrames_left, TextFrames_right, TextFrames_top, TextFrames_bot;
import TextFrames_Parc TextFrames_defParc;

import LONGINT *TextFrames_ParcDesc__typ;
import LONGINT *TextFrames_Location__typ;
import LONGINT *TextFrames_FrameDesc__typ;
import LONGINT *TextFrames_DisplayMsg__typ;
import LONGINT *TextFrames_TrackMsg__typ;
import LONGINT *TextFrames_FocusMsg__typ;
import LONGINT *TextFrames_NotifyMsg__typ;
import LONGINT *TextFrames_UpdateMsg__typ;
import LONGINT *TextFrames_InsertElemMsg__typ;

import void TextFrames_Handle (Display_Frame f, Display_FrameMsg *msg, LONGINT *msg__typ);
import void TextFrames_LocateChar (TextFrames_Frame F, INTEGER x, INTEGER y, TextFrames_Location *loc, LONGINT *loc__typ);
import void TextFrames_LocateLine (TextFrames_Frame F, INTEGER y, TextFrames_Location *loc, LONGINT *loc__typ);
import void TextFrames_LocatePos (TextFrames_Frame F, LONGINT pos, TextFrames_Location *loc, LONGINT *loc__typ);
import void TextFrames_LocateWord (TextFrames_Frame F, INTEGER x, INTEGER y, TextFrames_Location *loc, LONGINT *loc__typ);
import void TextFrames_Mark (TextFrames_Frame F, INTEGER mark);
import TextFrames_Frame TextFrames_NewMenu (CHAR *name, LONGINT name__len, CHAR *commands, LONGINT commands__len);
import TextFrames_Frame TextFrames_NewText (Texts_Text T, LONGINT pos);
import void TextFrames_NotifyDisplay (Texts_Text T, INTEGER op, LONGINT beg, LONGINT end);
import void TextFrames_Open (TextFrames_Frame F, Texts_Text T, LONGINT pos);
import void TextFrames_ParcBefore (Texts_Text T, LONGINT pos, TextFrames_Parc *P, LONGINT *beg);
import LONGINT TextFrames_Pos (TextFrames_Frame F, INTEGER x, INTEGER y);
import void TextFrames_RemoveCaret (TextFrames_Frame F);
import void TextFrames_RemoveSelection (TextFrames_Frame F);
import void TextFrames_SetCaret (TextFrames_Frame F, LONGINT pos);
import void TextFrames_SetSelection (TextFrames_Frame F, LONGINT beg, LONGINT end);
import void TextFrames_Show (TextFrames_Frame F, LONGINT pos);
import Texts_Text TextFrames_Text (CHAR *name, LONGINT name__len);
import void TextFrames_TrackCaret (TextFrames_Frame F, INTEGER *x, INTEGER *y, SET *keysum);
import void TextFrames_TrackLine (TextFrames_Frame F, INTEGER *x, INTEGER *y, LONGINT *org, SET *keysum);
import void TextFrames_TrackSelection (TextFrames_Frame F, INTEGER *x, INTEGER *y, SET *keysum);
import void TextFrames_TrackWord (TextFrames_Frame F, INTEGER *x, INTEGER *y, LONGINT *pos, SET *keysum);
import void *TextFrames__init(void);


#endif
