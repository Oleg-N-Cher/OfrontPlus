/* Ofront 1.2 -xtspka */

#ifndef In__h
#define In__h

#include "SYSTEM.h"


import BOOLEAN In_Done;


import void In_Char (CHAR *ch);
import void In_Int (INTEGER *i);
import void In_LongInt (LONGINT *i);
import void In_LongReal (LONGREAL *y);
import void In_Name (CHAR *name, LONGINT name__len);
import void In_Open (void);
import void In_Real (REAL *x);
import void In_String (CHAR *str, LONGINT str__len);
import void *In__init(void);


#endif
