/* Ofront 1.2 -xtspka */

#ifndef Kepler4__h
#define Kepler4__h

#include "SYSTEM.h"
#include "Files.h"
#include "Fonts.h"
#include "KeplerFrames.h"
#include "KeplerGraphs.h"
#include "KeplerPorts.h"

typedef
	struct Kepler4_GalaxyDesc *Kepler4_Galaxy;

typedef
	struct Kepler4_GalaxyDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		KeplerGraphs_Graph G;
	} Kepler4_GalaxyDesc;

import void Kepler4_Galaxy_Draw (Kepler4_Galaxy self, KeplerPorts_Port F);
import void Kepler4_Galaxy_Read (Kepler4_Galaxy self, Files_Rider *R, LONGINT *R__typ);
import void Kepler4_Galaxy_Write (Kepler4_Galaxy self, Files_Rider *R, LONGINT *R__typ);

typedef
	struct Kepler4_IconDesc *Kepler4_Icon;

typedef
	struct Kepler4_IconDesc { /* KeplerFrames_ButtonDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		CHAR cmd[32], par[32];
		Fonts_Font fnt;
		char _prvt0[4];
	} Kepler4_IconDesc;

import void Kepler4_Icon_Draw (Kepler4_Icon I, KeplerPorts_Port F);
import void Kepler4_Icon_Execute (Kepler4_Icon I, SET keys);
import void Kepler4_Icon_Read (Kepler4_Icon I, Files_Rider *R, LONGINT *R__typ);
import void Kepler4_Icon_Write (Kepler4_Icon I, Files_Rider *R, LONGINT *R__typ);



import LONGINT *Kepler4_IconDesc__typ;
import LONGINT *Kepler4_GalaxyDesc__typ;

import void Kepler4_NewButton (void);
import void Kepler4_NewGalaxy (void);
import void Kepler4_NewIcon (void);
import void Kepler4_UpdateButton (void);
import void *Kepler4__init(void);


#endif
