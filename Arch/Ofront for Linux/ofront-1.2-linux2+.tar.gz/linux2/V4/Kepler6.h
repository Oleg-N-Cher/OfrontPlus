/* Ofront 1.2 -xtspka */

#ifndef Kepler6__h
#define Kepler6__h

#include "SYSTEM.h"
#include "KeplerGraphs.h"
#include "KeplerPorts.h"

typedef
	struct Kepler6_BezierDesc *Kepler6_Bezier;

typedef
	struct Kepler6_BezierDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler6_BezierDesc;

import void Kepler6_Bezier_Draw (Kepler6_Bezier s, KeplerPorts_Port f);

typedef
	struct Kepler6_CRSplineDesc *Kepler6_CRSpline;

typedef
	struct Kepler6_CRSplineDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler6_CRSplineDesc;

import void Kepler6_CRSpline_Draw (Kepler6_CRSpline s, KeplerPorts_Port f);



import LONGINT *Kepler6_CRSplineDesc__typ;
import LONGINT *Kepler6_BezierDesc__typ;

import void Kepler6_NewBezier (void);
import void Kepler6_NewCRSpline (void);
import void Kepler6_NewClosedBezier (void);
import void Kepler6_NewClosedCRSpline (void);
import void *Kepler6__init(void);


#endif
