/* Ofront 1.2 -xtspka */

#ifndef TextPFrames__h
#define TextPFrames__h

#include "SYSTEM.h"
#include "Display.h"
#include "Fonts.h"
#include "TextFrames.h"
#include "Texts.h"

typedef
	struct TextPFrames_FrameDesc *TextPFrames_Frame;

typedef
	struct TextPFrames_Location {
		LONGINT org, pos;
		INTEGER x, y, dx, dy;
		char _prvt0[5];
	} TextPFrames_Location;

typedef
	struct TextPFrames_FrameDesc { /* TextFrames_FrameDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		Texts_Text text;
		LONGINT org;
		INTEGER col, left, right, top, bot, markH, barW;
		LONGINT time;
		BOOLEAN hasCar, hasSel, showsParcs;
		TextFrames_Location carloc, selbeg, selend;
		Display_Frame focus;
		char _prvt0[4];
		TextPFrames_Location CarLoc, SelBeg, SelEnd;
		char _prvt1[4108];
	} TextPFrames_FrameDesc;



import LONGINT *TextPFrames_Location__typ;
import LONGINT *TextPFrames_FrameDesc__typ;

import void TextPFrames_BegOfLine (Texts_Text T, LONGINT *pos, BOOLEAN adjust);
import void TextPFrames_Call (TextPFrames_Frame F, LONGINT pos, BOOLEAN new);
import void TextPFrames_Copy (TextPFrames_Frame SF, TextPFrames_Frame DF);
import void TextPFrames_Edit (TextPFrames_Frame F, INTEGER x, INTEGER y, SET keysum);
import void TextPFrames_GetPagination (TextPFrames_Frame F, INTEGER *pages, INTEGER *first, INTEGER *width, LONGINT *porg, LONGINT porg__len);
import void TextPFrames_Handle (Display_Frame f, Display_FrameMsg *msg, LONGINT *msg__typ);
import void TextPFrames_LocateChar (TextPFrames_Frame F, INTEGER x, INTEGER y, TextPFrames_Location *loc, LONGINT *loc__typ);
import void TextPFrames_LocateLine (TextPFrames_Frame F, INTEGER y, TextPFrames_Location *loc, LONGINT *loc__typ);
import void TextPFrames_LocatePage (TextPFrames_Frame F, LONGINT org, LONGINT *porg, INTEGER *pno);
import void TextPFrames_LocatePos (TextPFrames_Frame F, LONGINT pos, TextPFrames_Location *loc, LONGINT *loc__typ);
import void TextPFrames_LocateWord (TextPFrames_Frame F, INTEGER x, INTEGER y, TextPFrames_Location *loc, LONGINT *loc__typ);
import void TextPFrames_Neutralize (TextPFrames_Frame F);
import TextPFrames_Frame TextPFrames_NewText (Texts_Text T, LONGINT pos);
import void TextPFrames_NotifyElems (TextPFrames_Frame F, Display_FrameMsg *msg, LONGINT *msg__typ);
import void TextPFrames_Open (TextPFrames_Frame F, Texts_Text T, LONGINT pos);
import void TextPFrames_PassSubFocus (TextPFrames_Frame F, Display_Frame f);
import LONGINT TextPFrames_Pos (TextPFrames_Frame F, INTEGER x, INTEGER y);
import void TextPFrames_RemoveCaret (TextPFrames_Frame F);
import void TextPFrames_RemoveSelection (TextPFrames_Frame F);
import void TextPFrames_Resize (TextPFrames_Frame F, INTEGER x, INTEGER y, INTEGER w, INTEGER h);
import void TextPFrames_SetCaret (TextPFrames_Frame F, LONGINT pos);
import void TextPFrames_SetPagination (TextPFrames_Frame F, INTEGER pages, INTEGER first, INTEGER width, LONGINT *porg, LONGINT porg__len);
import void TextPFrames_SetSelection (TextPFrames_Frame F, LONGINT beg, LONGINT end);
import void TextPFrames_Show (TextPFrames_Frame F, LONGINT pos);
import Display_Frame TextPFrames_ThisSubFrame (TextPFrames_Frame F, INTEGER x, INTEGER y);
import void TextPFrames_TouchElem (TextPFrames_Frame F, INTEGER *x, INTEGER *y, SET *keysum);
import void TextPFrames_TrackCaret (TextPFrames_Frame F, INTEGER *x, INTEGER *y, SET *keysum);
import void TextPFrames_TrackLine (TextPFrames_Frame F, INTEGER *x, INTEGER *y, LONGINT *org, SET *keysum);
import void TextPFrames_TrackSelection (TextPFrames_Frame F, INTEGER *x, INTEGER *y, SET *keysum);
import void TextPFrames_TrackWord (TextPFrames_Frame F, INTEGER *x, INTEGER *y, LONGINT *pos, SET *keysum);
import void TextPFrames_Update (TextPFrames_Frame F, TextFrames_UpdateMsg *msg, LONGINT *msg__typ);
import void TextPFrames_Write (TextPFrames_Frame F, CHAR ch, Fonts_Font fnt, SHORTINT col, SHORTINT voff);
import void *TextPFrames__init(void);


#endif
