/* Ofront 1.2 -xtspka */

#ifndef Colors__h
#define Colors__h

#include "SYSTEM.h"




import void Colors_Get (void);
import void Colors_Load (void);
import void Colors_Open (void);
import void Colors_OpenHLS (void);
import void Colors_OpenRGB (void);
import void Colors_Set (void);
import void Colors_Store (void);
import void *Colors__init(void);


#endif
