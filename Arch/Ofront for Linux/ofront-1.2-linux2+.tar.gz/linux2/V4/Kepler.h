/* Ofront 1.2 -xtspka */

#ifndef Kepler__h
#define Kepler__h

#include "SYSTEM.h"




import void Kepler_AlignToGrid (void);
import void Kepler_AlignX (void);
import void Kepler_AlignY (void);
import void Kepler_Constellations (void);
import void Kepler_Delete (void);
import void Kepler_Join (void);
import void Kepler_Open (void);
import void Kepler_Print (void);
import void Kepler_Recall (void);
import void Kepler_Reset (void);
import void Kepler_RotatePoints (void);
import void Kepler_ScalePoints (void);
import void Kepler_SendBack (void);
import void Kepler_SetGrid (void);
import void Kepler_SetScale (void);
import void Kepler_Split (void);
import void Kepler_Store (void);
import void *Kepler__init(void);


#endif
