/* Ofront 1.2 -xtspka */

#ifndef System__h
#define System__h

#include "SYSTEM.h"
#include "Unix.h"




import void System_ChangeDirectory (void);
import void System_ClearLog (void);
import void System_Close (void);
import void System_CloseTrack (void);
import void System_Collect (void);
import void System_Copy (void);
import void System_CopyFiles (void);
import void System_DeleteFiles (void);
import void System_Directory (void);
import void System_Execute (void);
import void System_Free (void);
import void System_Grow (void);
import void System_Open (void);
import void System_OpenLog (void);
import void System_Quit (void);
import void System_Recall (void);
import void System_RenameFiles (void);
import void System_SetColor (void);
import void System_SetFont (void);
import void System_SetOffset (void);
import void System_SetUser (void);
import void System_ShowCommands (void);
import void System_ShowModules (void);
import void System_Time (void);
import void System_Trap (LONGINT sig, LONGINT code, Unix_SigCtxPtr scp);
import void System_Watch (void);
import void *System__init(void);


#endif
