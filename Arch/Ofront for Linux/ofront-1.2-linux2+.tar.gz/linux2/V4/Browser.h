/* Ofront 1.2 -xtspka */

#ifndef Browser__h
#define Browser__h

#include "SYSTEM.h"




import void Browser_ShowDef (void);
import void *Browser__init(void);


#endif
