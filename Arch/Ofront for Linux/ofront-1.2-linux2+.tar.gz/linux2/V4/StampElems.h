/* Ofront 1.2 -xtspka */

#ifndef StampElems__h
#define StampElems__h

#include "SYSTEM.h"




import void StampElems_Alloc (void);
import void StampElems_Insert (void);
import void *StampElems__init(void);


#endif
