/* Ofront 1.2 -xtspka */

#ifndef Math__h
#define Math__h

#include "SYSTEM.h"




import REAL Math_arctan (REAL x);
import REAL Math_cos (REAL x);
import REAL Math_exp (REAL x);
import REAL Math_ln (REAL x);
import REAL Math_sin (REAL x);
import REAL Math_sqrt (REAL x);
import void *Math__init(void);


#endif
