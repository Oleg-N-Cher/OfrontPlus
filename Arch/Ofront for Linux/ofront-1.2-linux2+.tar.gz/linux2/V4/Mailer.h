/* Ofront 1.2 -xtspka */

#ifndef Mailer__h
#define Mailer__h

#include "SYSTEM.h"


import CHAR Mailer_MAIL[110], Mailer_MBOX[110];


import void Mailer_Append (void);
import void Mailer_CutLines (void);
import void Mailer_Delete (void);
import void Mailer_Mailbox (void);
import void Mailer_Mono (void);
import void Mailer_Post (void);
import void Mailer_Quote (void);
import void Mailer_Reply (void);
import void Mailer_Send (void);
import void Mailer_Show (void);
import void Mailer_Store (void);
import void *Mailer__init(void);


#endif
