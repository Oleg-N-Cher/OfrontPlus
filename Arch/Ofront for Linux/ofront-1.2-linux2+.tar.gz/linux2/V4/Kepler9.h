/* Ofront 1.2 -xtspka */

#ifndef Kepler9__h
#define Kepler9__h

#include "SYSTEM.h"
#include "Files.h"
#include "KeplerGraphs.h"

typedef
	struct Kepler9_CircleIntersection *Kepler9_CircleInter;

typedef
	struct Kepler9_CircleIntersection { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
		SHORTINT sign;
	} Kepler9_CircleIntersection;

import void Kepler9_CircleInter_Calc (Kepler9_CircleInter self);
import void Kepler9_CircleInter_Read (Kepler9_CircleInter self, Files_Rider *r, LONGINT *r__typ);
import void Kepler9_CircleInter_Write (Kepler9_CircleInter self, Files_Rider *r, LONGINT *r__typ);

typedef
	struct Kepler9_CircleLineIntersection *Kepler9_CircleLineInter;

typedef
	struct Kepler9_CircleLineIntersection { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
		SHORTINT sign;
	} Kepler9_CircleLineIntersection;

import void Kepler9_CircleLineInter_Calc (Kepler9_CircleLineInter self);
import void Kepler9_CircleLineInter_Read (Kepler9_CircleLineInter self, Files_Rider *r, LONGINT *r__typ);
import void Kepler9_CircleLineInter_Write (Kepler9_CircleLineInter self, Files_Rider *r, LONGINT *r__typ);

typedef
	struct Kepler9_ExtensionDesc *Kepler9_Extension;

typedef
	struct Kepler9_ExtensionDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler9_ExtensionDesc;

import void Kepler9_Extension_Calc (Kepler9_Extension self);

typedef
	struct Kepler9_IntersectionDesc *Kepler9_Intersection;

typedef
	struct Kepler9_IntersectionDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler9_IntersectionDesc;

import void Kepler9_Intersection_Calc (Kepler9_Intersection self);

typedef
	struct Kepler9_ParallelDesc *Kepler9_Parallel;

typedef
	struct Kepler9_ParallelDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler9_ParallelDesc;

import void Kepler9_Parallel_Calc (Kepler9_Parallel self);

typedef
	struct Kepler9_RightAngleDesc *Kepler9_RightAngle;

typedef
	struct Kepler9_RightAngleDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler9_RightAngleDesc;

import void Kepler9_RightAngle_Calc (Kepler9_RightAngle self);

typedef
	struct Kepler9_TangentDesc *Kepler9_Tangent;

typedef
	struct Kepler9_TangentDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
		SHORTINT sign;
	} Kepler9_TangentDesc;

import void Kepler9_Tangent_Calc (Kepler9_Tangent self);
import void Kepler9_Tangent_Read (Kepler9_Tangent self, Files_Rider *r, LONGINT *r__typ);
import void Kepler9_Tangent_Write (Kepler9_Tangent self, Files_Rider *r, LONGINT *r__typ);



import LONGINT *Kepler9_ParallelDesc__typ;
import LONGINT *Kepler9_RightAngleDesc__typ;
import LONGINT *Kepler9_IntersectionDesc__typ;
import LONGINT *Kepler9_ExtensionDesc__typ;
import LONGINT *Kepler9_TangentDesc__typ;
import LONGINT *Kepler9_CircleIntersection__typ;
import LONGINT *Kepler9_CircleLineIntersection__typ;

import void Kepler9_NewCircleIntersection (void);
import void Kepler9_NewCircleLineIntersect (void);
import void Kepler9_NewExtension (void);
import void Kepler9_NewLineIntersection (void);
import void Kepler9_NewParallel (void);
import void Kepler9_NewRightAngle (void);
import void Kepler9_NewTangent (void);
import void *Kepler9__init(void);


#endif
