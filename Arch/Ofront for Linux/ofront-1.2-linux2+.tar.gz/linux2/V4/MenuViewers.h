/* Ofront 1.2 -xtspka */

#ifndef MenuViewers__h
#define MenuViewers__h

#include "SYSTEM.h"
#include "Display.h"
#include "Viewers.h"

typedef
	struct MenuViewers_ModifyMsg { /* Display_FrameMsg */
		INTEGER id, dY, Y, H;
	} MenuViewers_ModifyMsg;

typedef
	struct MenuViewers_ViewerDesc *MenuViewers_Viewer;

typedef
	struct MenuViewers_ViewerDesc { /* Viewers_ViewerDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER state;
		INTEGER menuH;
	} MenuViewers_ViewerDesc;


import MenuViewers_Viewer MenuViewers_Ancestor;

import LONGINT *MenuViewers_ViewerDesc__typ;
import LONGINT *MenuViewers_ModifyMsg__typ;

import void MenuViewers_Handle (Display_Frame V, Display_FrameMsg *M, LONGINT *M__typ);
import MenuViewers_Viewer MenuViewers_New (Display_Frame Menu, Display_Frame Main, INTEGER menuH, INTEGER X, INTEGER Y);
import void *MenuViewers__init(void);


#endif
