/* Ofront 1.2 -xtspka */

#ifndef KeplerElems__h
#define KeplerElems__h

#include "SYSTEM.h"




import void KeplerElems_Alloc (void);
import void KeplerElems_Insert (void);
import void KeplerElems_Update (void);
import void *KeplerElems__init(void);


#endif
