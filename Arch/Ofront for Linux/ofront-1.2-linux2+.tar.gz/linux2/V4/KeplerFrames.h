/* Ofront 1.2 -xtspka */

#ifndef KeplerFrames__h
#define KeplerFrames__h

#include "SYSTEM.h"
#include "Display.h"
#include "Files.h"
#include "Fonts.h"
#include "KeplerGraphs.h"
#include "KeplerPorts.h"

typedef
	struct KeplerFrames_ButtonDesc *KeplerFrames_Button;

typedef
	struct KeplerFrames_ButtonDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		CHAR cmd[32], par[32];
	} KeplerFrames_ButtonDesc;

import void KeplerFrames_Button_Execute (KeplerFrames_Button B, SET keys);
typedef
	struct KeplerFrames_FrameDesc *KeplerFrames_Frame;

import void KeplerFrames_Button_HandleMouse (KeplerFrames_Button B, KeplerFrames_Frame F, INTEGER x, INTEGER y, SET keys);
import void KeplerFrames_Button_Read (KeplerFrames_Button B, Files_Rider *R, LONGINT *R__typ);
import void KeplerFrames_Button_Write (KeplerFrames_Button B, Files_Rider *R, LONGINT *R__typ);
#define __KeplerFrames_Button_Execute(B, keys) __SEND(__TYPEOF(B), KeplerFrames_Button_Execute, 4, void(*)(KeplerFrames_Button, SET), (B, keys))
#define __KeplerFrames_Button_HandleMouse(B, F, x, y, keys) __SEND(__TYPEOF(B), KeplerFrames_Button_HandleMouse, 5, void(*)(KeplerFrames_Button, KeplerFrames_Frame, INTEGER, INTEGER, SET), (B, F, x, y, keys))

typedef
	struct KeplerFrames_CaptionDesc *KeplerFrames_Caption;

typedef
	struct KeplerFrames_CaptionDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		CHAR s[128];
		Fonts_Font fnt;
		SHORTINT align;
	} KeplerFrames_CaptionDesc;

import void KeplerFrames_Caption_Draw (KeplerFrames_Caption C, KeplerPorts_Port F);
import void KeplerFrames_Caption_Read (KeplerFrames_Caption C, Files_Rider *R, LONGINT *R__typ);
import void KeplerFrames_Caption_Write (KeplerFrames_Caption C, Files_Rider *R, LONGINT *R__typ);

typedef
	struct KeplerFrames_FocusPointDesc *KeplerFrames_FocusPoint;

typedef
	struct KeplerFrames_FocusPointDesc {
		KeplerFrames_FocusPoint next;
		KeplerGraphs_Star p;
	} KeplerFrames_FocusPointDesc;

typedef
	struct KeplerFrames_FrameDesc { /* KeplerPorts_DisplayPortDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER x0, y0, scale;
		KeplerPorts_Port ext;
		KeplerGraphs_Graph G;
		INTEGER col, grid;
	} KeplerFrames_FrameDesc;

import void KeplerFrames_Frame_Consume (KeplerFrames_Frame F, CHAR ch);
import void KeplerFrames_Frame_EditFrame (KeplerFrames_Frame F, INTEGER x, INTEGER y, SET keys);
import void KeplerFrames_Frame_Extend (KeplerFrames_Frame F, INTEGER newY);
import void KeplerFrames_Frame_Invert (KeplerFrames_Frame F, KeplerGraphs_Star p);
import void KeplerFrames_Frame_Neutralize (KeplerFrames_Frame F);
import void KeplerFrames_Frame_Reduce (KeplerFrames_Frame F, INTEGER newY);
import void KeplerFrames_Frame_Restore (KeplerFrames_Frame F, INTEGER X, INTEGER Y, INTEGER W, INTEGER H);
import void KeplerFrames_Frame_TrackMouse (KeplerFrames_Frame F, INTEGER x, INTEGER y, SET keys);
#define __KeplerFrames_Frame_Consume(F, ch) __SEND(__TYPEOF(F), KeplerFrames_Frame_Consume, 12, void(*)(KeplerFrames_Frame, CHAR), (F, ch))
#define __KeplerFrames_Frame_EditFrame(F, x, y, keys) __SEND(__TYPEOF(F), KeplerFrames_Frame_EditFrame, 13, void(*)(KeplerFrames_Frame, INTEGER, INTEGER, SET), (F, x, y, keys))
#define __KeplerFrames_Frame_Extend(F, newY) __SEND(__TYPEOF(F), KeplerFrames_Frame_Extend, 14, void(*)(KeplerFrames_Frame, INTEGER), (F, newY))
#define __KeplerFrames_Frame_Invert(F, p) __SEND(__TYPEOF(F), KeplerFrames_Frame_Invert, 15, void(*)(KeplerFrames_Frame, KeplerGraphs_Star), (F, p))
#define __KeplerFrames_Frame_Neutralize(F) __SEND(__TYPEOF(F), KeplerFrames_Frame_Neutralize, 16, void(*)(KeplerFrames_Frame), (F))
#define __KeplerFrames_Frame_Reduce(F, newY) __SEND(__TYPEOF(F), KeplerFrames_Frame_Reduce, 17, void(*)(KeplerFrames_Frame, INTEGER), (F, newY))
#define __KeplerFrames_Frame_Restore(F, X, Y, W, H) __SEND(__TYPEOF(F), KeplerFrames_Frame_Restore, 18, void(*)(KeplerFrames_Frame, INTEGER, INTEGER, INTEGER, INTEGER), (F, X, Y, W, H))
#define __KeplerFrames_Frame_TrackMouse(F, x, y, keys) __SEND(__TYPEOF(F), KeplerFrames_Frame_TrackMouse, 19, void(*)(KeplerFrames_Frame, INTEGER, INTEGER, SET), (F, x, y, keys))

typedef
	void (*KeplerFrames_Notifier)(INTEGER, KeplerGraphs_Graph, KeplerGraphs_Object, KeplerPorts_Port);

typedef
	struct KeplerFrames_SelMsg { /* Display_FrameMsg */
		LONGINT time;
		KeplerGraphs_Graph G;
	} KeplerFrames_SelMsg;

typedef
	struct KeplerFrames_UpdateMsg { /* Display_FrameMsg */
		INTEGER id;
		KeplerGraphs_Graph G;
		KeplerGraphs_Object O;
		KeplerPorts_Port P;
	} KeplerFrames_UpdateMsg;


import KeplerGraphs_Graph KeplerFrames_Focus;
import KeplerFrames_FocusPoint KeplerFrames_first, KeplerFrames_last;
import INTEGER KeplerFrames_nofpts;
import KeplerFrames_Caption KeplerFrames_focus;
import INTEGER KeplerFrames_carpos;

import LONGINT *KeplerFrames_FocusPointDesc__typ;
import LONGINT *KeplerFrames_ButtonDesc__typ;
import LONGINT *KeplerFrames_CaptionDesc__typ;
import LONGINT *KeplerFrames_FrameDesc__typ;
import LONGINT *KeplerFrames_UpdateMsg__typ;
import LONGINT *KeplerFrames_SelMsg__typ;

import void KeplerFrames_AlignToGrid (KeplerFrames_Frame F, INTEGER *X, INTEGER *Y);
import void KeplerFrames_AppendFocusPoint (KeplerGraphs_Star p);
import void KeplerFrames_ConsumePoint (KeplerGraphs_Star *p);
import void KeplerFrames_DeleteFocusPoint (KeplerFrames_Frame F);
import void KeplerFrames_GetMouse (KeplerFrames_Frame F, INTEGER *x, INTEGER *y, SET *keys);
import void KeplerFrames_GetPoint (KeplerGraphs_Star *p);
import void KeplerFrames_GetSelection (KeplerGraphs_Graph *sel);
import void KeplerFrames_Handle (Display_Frame F, Display_FrameMsg *M, LONGINT *M__typ);
import BOOLEAN KeplerFrames_IsFocusPoint (KeplerGraphs_Star p);
import KeplerFrames_Button KeplerFrames_MarkedButton (void);
import void KeplerFrames_MoveOrigin (KeplerFrames_Frame F, INTEGER x0, INTEGER y0);
import KeplerFrames_Frame KeplerFrames_New (KeplerGraphs_Graph G);
import void KeplerFrames_NotifyDisplay (INTEGER op, KeplerGraphs_Graph G, KeplerGraphs_Object O, KeplerPorts_Port P);
import void KeplerFrames_Open (KeplerFrames_Frame F, KeplerGraphs_Graph G, INTEGER grid, INTEGER scale, KeplerGraphs_Notifier notify, Display_Handler handle);
import KeplerFrames_Button KeplerFrames_ThisButton (KeplerGraphs_Graph G, INTEGER x, INTEGER y);
import KeplerFrames_Caption KeplerFrames_ThisCaption (KeplerGraphs_Graph G, INTEGER x, INTEGER y);
import void *KeplerFrames__init(void);


#endif
