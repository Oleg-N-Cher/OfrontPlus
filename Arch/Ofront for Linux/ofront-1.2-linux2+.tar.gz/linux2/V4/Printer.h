/* Ofront 1.2 -xtspka */

#ifndef Printer__h
#define Printer__h

#include "SYSTEM.h"


import INTEGER Printer_res, Printer_PageWidth, Printer_PageHeight;


import void Printer_Circle (INTEGER x0, INTEGER y0, INTEGER r);
import void Printer_Close (void);
import void Printer_ContString (CHAR *s, LONGINT s__len, CHAR *fname, LONGINT fname__len);
import void Printer_Ellipse (INTEGER x0, INTEGER y0, INTEGER a, INTEGER b);
import void Printer_Line (INTEGER x0, INTEGER y0, INTEGER x1, INTEGER y1);
import void Printer_Open (CHAR *name, LONGINT name__len, CHAR *user, LONGINT user__len, LONGINT password);
import void Printer_Page (INTEGER nofcopies);
import void Printer_Picture (INTEGER x, INTEGER y, INTEGER w, INTEGER h, INTEGER mode, LONGINT adr);
import void Printer_ReplConst (INTEGER x, INTEGER y, INTEGER w, INTEGER h);
import void Printer_ReplPattern (INTEGER x, INTEGER y, INTEGER w, INTEGER h, INTEGER col);
import void Printer_Spline (INTEGER x0, INTEGER y0, INTEGER n, INTEGER open, INTEGER *X, LONGINT X__len, INTEGER *Y, LONGINT Y__len);
import void Printer_String (INTEGER x, INTEGER y, CHAR *s, LONGINT s__len, CHAR *fname, LONGINT fname__len);
import void Printer_UseColor (INTEGER red, INTEGER green, INTEGER blue);
import void Printer_UseListFont (CHAR *name, LONGINT name__len);
import void *Printer__init(void);


#endif
