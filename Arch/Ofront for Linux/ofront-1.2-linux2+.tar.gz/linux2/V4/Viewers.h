/* Ofront 1.2 -xtspka */

#ifndef Viewers__h
#define Viewers__h

#include "SYSTEM.h"
#include "Display.h"

typedef
	struct Viewers_ViewerDesc *Viewers_Viewer;

typedef
	struct Viewers_ViewerDesc { /* Display_FrameDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER state;
	} Viewers_ViewerDesc;

typedef
	struct Viewers_ViewerMsg { /* Display_FrameMsg */
		INTEGER id, X, Y, W, H, state;
	} Viewers_ViewerMsg;


import INTEGER Viewers_curW, Viewers_minH;

import LONGINT *Viewers_ViewerDesc__typ;
import LONGINT *Viewers_ViewerMsg__typ;

import void Viewers_Broadcast (Display_FrameMsg *M, LONGINT *M__typ);
import void Viewers_Change (Viewers_Viewer V, INTEGER Y);
import void Viewers_Close (Viewers_Viewer V);
import void Viewers_CloseTrack (INTEGER X);
import void Viewers_InitTrack (INTEGER W, INTEGER H, Viewers_Viewer Filler);
import void Viewers_Locate (INTEGER X, INTEGER H, Display_Frame *fil, Display_Frame *bot, Display_Frame *alt, Display_Frame *max);
import Viewers_Viewer Viewers_Next (Viewers_Viewer V);
import void Viewers_Open (Viewers_Viewer V, INTEGER X, INTEGER Y);
import void Viewers_OpenTrack (INTEGER X, INTEGER W, Viewers_Viewer Filler);
import void Viewers_Recall (Viewers_Viewer *V);
import Viewers_Viewer Viewers_This (INTEGER X, INTEGER Y);
import void *Viewers__init(void);


#endif
