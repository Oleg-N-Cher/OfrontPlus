/* Ofront 1.2 -xtspka */

#ifndef Miscellaneous__h
#define Miscellaneous__h

#include "SYSTEM.h"




import void Miscellaneous_Cleanup (void);
import void Miscellaneous_ConvertBlanks (void);
import void Miscellaneous_ConvertTabs (void);
import void Miscellaneous_Copy (void);
import void Miscellaneous_CountLines (void);
import void Miscellaneous_Cut (void);
import void Miscellaneous_Paste (void);
import void *Miscellaneous__init(void);


#endif
