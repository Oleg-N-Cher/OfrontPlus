/* Ofront 1.2 -xtspka */

#ifndef Fonts__h
#define Fonts__h

#include "SYSTEM.h"
#include "Display.h"

typedef
	struct Fonts_FontDesc *Fonts_Font;

typedef
	CHAR Fonts_Name[32];

typedef
	struct Fonts_FontDesc {
		Fonts_Name name;
		INTEGER height, minX, maxX, minY, maxY;
		Display_Font raster;
		char _prvt0[4];
	} Fonts_FontDesc;


import Fonts_Font Fonts_Default;

import LONGINT *Fonts_FontDesc__typ;

import Fonts_Font Fonts_This (CHAR *name, LONGINT name__len);
import void *Fonts__init(void);


#endif
