/* Ofront 1.2 -xtspka */

#ifndef LineElems__h
#define LineElems__h

#include "SYSTEM.h"
#include "Files.h"
#include "Texts.h"

typedef
	struct LineElems_ElemDesc *LineElems_Elem;

typedef
	struct LineElems_ElemDesc { /* Texts_ElemDesc */
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
		SET opts;
		char _prvt2[4];
	} LineElems_ElemDesc;



import LONGINT *LineElems_ElemDesc__typ;

import void LineElems_Alloc (void);
import void LineElems_Copy (LineElems_Elem SE, LineElems_Elem DE);
import void LineElems_Draw (LineElems_Elem E, INTEGER x0, INTEGER y0, SHORTINT col);
import void LineElems_Handle (Texts_Elem E, Texts_ElemMsg *msg, LONGINT *msg__typ);
import void LineElems_Insert (void);
import void LineElems_Load (LineElems_Elem E, Files_Rider *r, LONGINT *r__typ);
import void LineElems_Prepare (LineElems_Elem E, LONGINT pos, LONGINT indent, BOOLEAN printing);
import void LineElems_Print (LineElems_Elem E, INTEGER x0, INTEGER y0, SHORTINT col);
import void LineElems_Store (LineElems_Elem E, Files_Rider *r, LONGINT *r__typ);
import void *LineElems__init(void);


#endif
