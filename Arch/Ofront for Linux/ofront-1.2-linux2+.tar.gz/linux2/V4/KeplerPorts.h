/* Ofront 1.2 -xtspka */

#ifndef KeplerPorts__h
#define KeplerPorts__h

#include "SYSTEM.h"
#include "Display.h"
#include "Fonts.h"

typedef
	struct KeplerPorts_BalloonPortDesc *KeplerPorts_BalloonPort;

typedef
	struct KeplerPorts_PortDesc *KeplerPorts_Port;

typedef
	struct KeplerPorts_PortDesc { /* Display_FrameDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER x0, y0, scale;
		KeplerPorts_Port ext;
	} KeplerPorts_PortDesc;

import INTEGER KeplerPorts_Port_CX (KeplerPorts_Port P, INTEGER x);
import INTEGER KeplerPorts_Port_CY (KeplerPorts_Port P, INTEGER y);
import INTEGER KeplerPorts_Port_Cx (KeplerPorts_Port P, INTEGER X);
import INTEGER KeplerPorts_Port_Cy (KeplerPorts_Port P, INTEGER Y);
import void KeplerPorts_Port_DrawCircle (KeplerPorts_Port P, INTEGER x, INTEGER y, INTEGER r, INTEGER col, INTEGER mode);
import void KeplerPorts_Port_DrawEllipse (KeplerPorts_Port P, INTEGER x, INTEGER y, INTEGER a, INTEGER b, INTEGER col, INTEGER mode);
import void KeplerPorts_Port_DrawLine (KeplerPorts_Port P, INTEGER x1, INTEGER y1, INTEGER x2, INTEGER y2, INTEGER col, INTEGER mode);
import void KeplerPorts_Port_DrawRect (KeplerPorts_Port P, INTEGER x, INTEGER y, INTEGER w, INTEGER h, INTEGER col, INTEGER mode);
import void KeplerPorts_Port_DrawString (KeplerPorts_Port P, INTEGER x, INTEGER y, CHAR *s, LONGINT s__len, Fonts_Font font, INTEGER col, INTEGER mode);
import void KeplerPorts_Port_FillCircle (KeplerPorts_Port P, INTEGER x, INTEGER y, INTEGER r, INTEGER col, INTEGER pat, INTEGER mode);
import void KeplerPorts_Port_FillQuad (KeplerPorts_Port P, INTEGER x1, INTEGER y1, INTEGER x2, INTEGER y2, INTEGER x3, INTEGER y3, INTEGER x4, INTEGER y4, INTEGER col, INTEGER pat, INTEGER mode);
import void KeplerPorts_Port_FillRect (KeplerPorts_Port P, INTEGER x, INTEGER y, INTEGER w, INTEGER h, INTEGER col, INTEGER pat, INTEGER mode);
#define __KeplerPorts_Port_CX(P, x) __SEND(__TYPEOF(P), KeplerPorts_Port_CX, 0, INTEGER(*)(KeplerPorts_Port, INTEGER), (P, x))
#define __KeplerPorts_Port_CY(P, y) __SEND(__TYPEOF(P), KeplerPorts_Port_CY, 1, INTEGER(*)(KeplerPorts_Port, INTEGER), (P, y))
#define __KeplerPorts_Port_Cx(P, X) __SEND(__TYPEOF(P), KeplerPorts_Port_Cx, 2, INTEGER(*)(KeplerPorts_Port, INTEGER), (P, X))
#define __KeplerPorts_Port_Cy(P, Y) __SEND(__TYPEOF(P), KeplerPorts_Port_Cy, 3, INTEGER(*)(KeplerPorts_Port, INTEGER), (P, Y))
#define __KeplerPorts_Port_DrawCircle(P, x, y, r, col, mode) __SEND(__TYPEOF(P), KeplerPorts_Port_DrawCircle, 4, void(*)(KeplerPorts_Port, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER), (P, x, y, r, col, mode))
#define __KeplerPorts_Port_DrawEllipse(P, x, y, a, b, col, mode) __SEND(__TYPEOF(P), KeplerPorts_Port_DrawEllipse, 5, void(*)(KeplerPorts_Port, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER), (P, x, y, a, b, col, mode))
#define __KeplerPorts_Port_DrawLine(P, x1, y1, x2, y2, col, mode) __SEND(__TYPEOF(P), KeplerPorts_Port_DrawLine, 6, void(*)(KeplerPorts_Port, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER), (P, x1, y1, x2, y2, col, mode))
#define __KeplerPorts_Port_DrawRect(P, x, y, w, h, col, mode) __SEND(__TYPEOF(P), KeplerPorts_Port_DrawRect, 7, void(*)(KeplerPorts_Port, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER), (P, x, y, w, h, col, mode))
#define __KeplerPorts_Port_DrawString(P, x, y, s, s__len, font, col, mode) __SEND(__TYPEOF(P), KeplerPorts_Port_DrawString, 8, void(*)(KeplerPorts_Port, INTEGER, INTEGER, CHAR*, LONGINT , Fonts_Font, INTEGER, INTEGER), (P, x, y, s, s__len, font, col, mode))
#define __KeplerPorts_Port_FillCircle(P, x, y, r, col, pat, mode) __SEND(__TYPEOF(P), KeplerPorts_Port_FillCircle, 9, void(*)(KeplerPorts_Port, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER), (P, x, y, r, col, pat, mode))
#define __KeplerPorts_Port_FillQuad(P, x1, y1, x2, y2, x3, y3, x4, y4, col, pat, mode) __SEND(__TYPEOF(P), KeplerPorts_Port_FillQuad, 10, void(*)(KeplerPorts_Port, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER), (P, x1, y1, x2, y2, x3, y3, x4, y4, col, pat, mode))
#define __KeplerPorts_Port_FillRect(P, x, y, w, h, col, pat, mode) __SEND(__TYPEOF(P), KeplerPorts_Port_FillRect, 11, void(*)(KeplerPorts_Port, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER), (P, x, y, w, h, col, pat, mode))

typedef
	struct KeplerPorts_BalloonPortDesc { /* KeplerPorts_PortDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER x0, y0, scale;
		KeplerPorts_Port ext;
	} KeplerPorts_BalloonPortDesc;

import void KeplerPorts_BalloonPort_DrawCircle (KeplerPorts_BalloonPort P, INTEGER x, INTEGER y, INTEGER r, INTEGER col, INTEGER mode);
import void KeplerPorts_BalloonPort_DrawEllipse (KeplerPorts_BalloonPort P, INTEGER x, INTEGER y, INTEGER a, INTEGER b, INTEGER col, INTEGER mode);
import void KeplerPorts_BalloonPort_DrawLine (KeplerPorts_BalloonPort P, INTEGER x1, INTEGER y1, INTEGER x2, INTEGER y2, INTEGER col, INTEGER mode);
import void KeplerPorts_BalloonPort_DrawRect (KeplerPorts_BalloonPort P, INTEGER x, INTEGER y, INTEGER w, INTEGER h, INTEGER col, INTEGER mode);
import void KeplerPorts_BalloonPort_DrawString (KeplerPorts_BalloonPort P, INTEGER x, INTEGER y, CHAR *s, LONGINT s__len, Fonts_Font font, INTEGER col, INTEGER mode);
import void KeplerPorts_BalloonPort_FillCircle (KeplerPorts_BalloonPort P, INTEGER x, INTEGER y, INTEGER r, INTEGER col, INTEGER pat, INTEGER mode);
import void KeplerPorts_BalloonPort_FillQuad (KeplerPorts_BalloonPort P, INTEGER x1, INTEGER y1, INTEGER x2, INTEGER y2, INTEGER x3, INTEGER y3, INTEGER x4, INTEGER y4, INTEGER col, INTEGER pat, INTEGER mode);
import void KeplerPorts_BalloonPort_FillRect (KeplerPorts_BalloonPort P, INTEGER x, INTEGER y, INTEGER w, INTEGER h, INTEGER col, INTEGER pat, INTEGER mode);

typedef
	struct KeplerPorts_DisplayPortDesc *KeplerPorts_DisplayPort;

typedef
	struct KeplerPorts_DisplayPortDesc { /* KeplerPorts_PortDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER x0, y0, scale;
		KeplerPorts_Port ext;
	} KeplerPorts_DisplayPortDesc;

import void KeplerPorts_DisplayPort_DrawCircle (KeplerPorts_DisplayPort P, INTEGER x, INTEGER y, INTEGER r, INTEGER col, INTEGER mode);
import void KeplerPorts_DisplayPort_DrawEllipse (KeplerPorts_DisplayPort P, INTEGER x, INTEGER y, INTEGER a, INTEGER b, INTEGER col, INTEGER mode);
import void KeplerPorts_DisplayPort_DrawLine (KeplerPorts_DisplayPort P, INTEGER x1, INTEGER y1, INTEGER x2, INTEGER y2, INTEGER col, INTEGER mode);
import void KeplerPorts_DisplayPort_DrawString (KeplerPorts_DisplayPort P, INTEGER x, INTEGER y, CHAR *s, LONGINT s__len, Fonts_Font font, INTEGER col, INTEGER mode);
import void KeplerPorts_DisplayPort_FillRect (KeplerPorts_DisplayPort P, INTEGER x, INTEGER y, INTEGER w, INTEGER h, INTEGER col, INTEGER pat, INTEGER mode);

typedef
	struct KeplerPorts_PrinterPortDesc *KeplerPorts_PrinterPort;

typedef
	struct KeplerPorts_PrinterPortDesc { /* KeplerPorts_PortDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER x0, y0, scale;
		KeplerPorts_Port ext;
	} KeplerPorts_PrinterPortDesc;

import void KeplerPorts_PrinterPort_DrawCircle (KeplerPorts_PrinterPort P, INTEGER x, INTEGER y, INTEGER r, INTEGER col, INTEGER mode);
import void KeplerPorts_PrinterPort_DrawEllipse (KeplerPorts_PrinterPort P, INTEGER x, INTEGER y, INTEGER a, INTEGER b, INTEGER col, INTEGER mode);
import void KeplerPorts_PrinterPort_DrawLine (KeplerPorts_PrinterPort P, INTEGER x1, INTEGER y1, INTEGER x2, INTEGER y2, INTEGER col, INTEGER mode);
import void KeplerPorts_PrinterPort_DrawString (KeplerPorts_PrinterPort P, INTEGER x, INTEGER y, CHAR *s, LONGINT s__len, Fonts_Font font, INTEGER col, INTEGER mode);
import void KeplerPorts_PrinterPort_FillRect (KeplerPorts_PrinterPort P, INTEGER x, INTEGER y, INTEGER w, INTEGER h, INTEGER col, INTEGER pat, INTEGER mode);



import LONGINT *KeplerPorts_PortDesc__typ;
import LONGINT *KeplerPorts_DisplayPortDesc__typ;
import LONGINT *KeplerPorts_PrinterPortDesc__typ;
import LONGINT *KeplerPorts_BalloonPortDesc__typ;

import void KeplerPorts_InitBalloon (KeplerPorts_BalloonPort P);
import INTEGER KeplerPorts_StringWidth (CHAR *s, LONGINT s__len, Fonts_Font f);
import void *KeplerPorts__init(void);


#endif
