/* Ofront 1.2 -xtspka */

#ifndef Kepler2__h
#define Kepler2__h

#include "SYSTEM.h"
#include "Files.h"
#include "KeplerGraphs.h"

typedef
	struct Kepler2_FractionDesc *Kepler2_Fraction;

typedef
	struct Kepler2_FractionDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
		LONGINT cnt, dn;
	} Kepler2_FractionDesc;

import void Kepler2_Fraction_Calc (Kepler2_Fraction self);
import void Kepler2_Fraction_Read (Kepler2_Fraction self, Files_Rider *R, LONGINT *R__typ);
import void Kepler2_Fraction_Write (Kepler2_Fraction self, Files_Rider *R, LONGINT *R__typ);

typedef
	struct Kepler2_OffsetDesc *Kepler2_Offset;

typedef
	struct Kepler2_OffsetDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
		INTEGER dx, dy;
	} Kepler2_OffsetDesc;

import void Kepler2_Offset_Calc (Kepler2_Offset self);
import void Kepler2_Offset_Read (Kepler2_Offset self, Files_Rider *R, LONGINT *R__typ);
import void Kepler2_Offset_Write (Kepler2_Offset self, Files_Rider *R, LONGINT *R__typ);

typedef
	struct Kepler2_XYDesc *Kepler2_XY;

typedef
	struct Kepler2_XYDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler2_XYDesc;

import void Kepler2_XY_Calc (Kepler2_XY self);



import LONGINT *Kepler2_FractionDesc__typ;
import LONGINT *Kepler2_XYDesc__typ;
import LONGINT *Kepler2_OffsetDesc__typ;

import void Kepler2_NewFractions (void);
import void Kepler2_NewOffset (void);
import void Kepler2_NewXY (void);
import void *Kepler2__init(void);


#endif
