/* Ofront 1.2 -xtspka */

#ifndef TableElems__h
#define TableElems__h

#include "SYSTEM.h"
#include "Display.h"
#include "Files.h"
#include "MenuViewers.h"
#include "Texts.h"

typedef
	struct TableElems_ElemDesc *TableElems_Elem;

typedef
	struct TableElems_ElemDesc { /* Texts_ElemDesc */
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
		Texts_Text def;
		char _prvt2[148];
	} TableElems_ElemDesc;

typedef
	struct TableElems_ViewerDesc *TableElems_Viewer;

typedef
	struct TableElems_ViewerDesc { /* MenuViewers_ViewerDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER state;
		INTEGER menuH;
		TableElems_Elem elem;
	} TableElems_ViewerDesc;



import LONGINT *TableElems_ElemDesc__typ;
import LONGINT *TableElems_ViewerDesc__typ;

import void TableElems_Alloc (void);
import void TableElems_Changed (TableElems_Elem E);
import Texts_Text TableElems_CopyText (Texts_Text T);
import void TableElems_Draw (TableElems_Elem E, Display_Frame F, INTEGER x0, INTEGER y0);
import void TableElems_Handle (Texts_Elem E, Texts_ElemMsg *msg, LONGINT *msg__typ);
import void TableElems_Insert (void);
import void TableElems_Load (TableElems_Elem E, Files_Rider *r, LONGINT *r__typ);
import void TableElems_Open (TableElems_Elem E, Texts_Text def);
import void TableElems_OpenViewer (TableElems_Elem E);
import void TableElems_Print (TableElems_Elem E, INTEGER pno, INTEGER x0, INTEGER y0);
import void TableElems_Store (TableElems_Elem E, Files_Rider *r, LONGINT *r__typ);
import void TableElems_Track (TableElems_Elem E, LONGINT pos, SET keys, INTEGER x, INTEGER y, INTEGER x0, INTEGER y0);
import void TableElems_Update (void);
import void *TableElems__init(void);


#endif
