/* Ofront 1.2 -xtspka */

#ifndef Display1__h
#define Display1__h

#include "SYSTEM.h"
#include "Display.h"




import void Display1_Circle (Display_Frame F, INTEGER col, INTEGER X, INTEGER Y, INTEGER R, INTEGER mode);
import void Display1_Ellipse (Display_Frame F, INTEGER col, INTEGER X, INTEGER Y, INTEGER A, INTEGER B, INTEGER mode);
import void Display1_GetPatternSize (LONGINT pat, INTEGER *w, INTEGER *h);
import void Display1_Line (Display_Frame F, INTEGER col, INTEGER X0, INTEGER Y0, INTEGER X1, INTEGER Y1, INTEGER mode);
import LONGINT Display1_ThisPattern (INTEGER n);
import void *Display1__init(void);


#endif
