/* Ofront 1.2 -xtspka */

#ifndef FontToBDF__h
#define FontToBDF__h

#include "SYSTEM.h"




import void FontToBDF_Convert (void);
import void *FontToBDF__init(void);


#endif
