/* Ofront 1.2 -xtspka */

#ifndef MenuElems__h
#define MenuElems__h

#include "SYSTEM.h"




import void MenuElems_Alloc (void);
import void MenuElems_Insert (void);
import void MenuElems_Update (void);
import void *MenuElems__init(void);


#endif
