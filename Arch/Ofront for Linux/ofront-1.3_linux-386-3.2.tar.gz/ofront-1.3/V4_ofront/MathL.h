/* Ofront 1.2 -xtspka */

#ifndef MathL__h
#define MathL__h

#include "SYSTEM.h"




import LONGREAL MathL_arctan (LONGREAL x);
import LONGREAL MathL_cos (LONGREAL x);
import LONGREAL MathL_exp (LONGREAL x);
import LONGREAL MathL_ln (LONGREAL x);
import LONGREAL MathL_sin (LONGREAL x);
import LONGREAL MathL_sqrt (LONGREAL x);
import void *MathL__init(void);


#endif
