/* Ofront 1.2 -xtspka */

#ifndef Display__h
#define Display__h

#include "SYSTEM.h"

typedef
	struct Display_Bytes {
		char _prvt0[1];
	} Display_Bytes;

typedef
	Display_Bytes *Display_Font;

typedef
	struct Display_FrameDesc *Display_Frame;

typedef
	struct Display_FrameMsg {
		char _prvt0[1];
	} Display_FrameMsg;

typedef
	void (*Display_Handler)(Display_Frame, Display_FrameMsg*, LONGINT *);

typedef
	struct Display_FrameDesc {
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
	} Display_FrameDesc;


import INTEGER Display_Bottom, Display_Left, Display_Width, Display_Height, Display_ColLeft, Display_UBottom;
import LONGINT Display_Unit, Display_primary, Display_secondary, Display_arrow, Display_cross, Display_star, Display_hook, Display_downArrow, Display_grey0, Display_grey1, Display_grey2, Display_ticks;

import LONGINT *Display_FrameMsg__typ;
import LONGINT *Display_FrameDesc__typ;
import LONGINT *Display_Bytes__typ;

import void Display_CopyBlock (INTEGER SX, INTEGER SY, INTEGER W, INTEGER H, INTEGER DX, INTEGER DY, INTEGER mode);
import void Display_CopyBlockC (Display_Frame F, INTEGER SX, INTEGER SY, INTEGER W, INTEGER H, INTEGER DX, INTEGER DY, INTEGER mode);
import void Display_CopyPattern (INTEGER col, LONGINT pat, INTEGER X, INTEGER Y, INTEGER mode);
import void Display_CopyPatternC (Display_Frame F, INTEGER col, LONGINT pat, INTEGER X, INTEGER Y, INTEGER mode);
import void Display_Dot (INTEGER col, INTEGER X, INTEGER Y, INTEGER mode);
import void Display_DotC (Display_Frame F, INTEGER col, INTEGER X, INTEGER Y, INTEGER mode);
import void Display_GetChar (Display_Font f, CHAR ch, INTEGER *dx, INTEGER *x, INTEGER *y, INTEGER *w, INTEGER *h, LONGINT *p);
import void Display_GetColor (INTEGER col, INTEGER *red, INTEGER *green, INTEGER *blue);
import LONGINT Display_Map (INTEGER X, INTEGER Y);
import LONGINT Display_NewPattern (SET *image, LONGINT image__len, INTEGER w, INTEGER h);
import void Display_ReplConst (INTEGER col, INTEGER X, INTEGER Y, INTEGER W, INTEGER H, INTEGER mode);
import void Display_ReplConstC (Display_Frame F, INTEGER col, INTEGER X, INTEGER Y, INTEGER W, INTEGER H, INTEGER mode);
import void Display_ReplPattern (INTEGER col, LONGINT pat, INTEGER X, INTEGER Y, INTEGER W, INTEGER H, INTEGER mode);
import void Display_ReplPatternC (Display_Frame F, INTEGER col, LONGINT pat, INTEGER X, INTEGER Y, INTEGER W, INTEGER H, INTEGER X0, INTEGER Y0, INTEGER mode);
import void Display_SetColor (INTEGER col, INTEGER red, INTEGER green, INTEGER blue);
import void Display_SetMode (INTEGER X, SET s);
import void *Display__init(void);


#endif
