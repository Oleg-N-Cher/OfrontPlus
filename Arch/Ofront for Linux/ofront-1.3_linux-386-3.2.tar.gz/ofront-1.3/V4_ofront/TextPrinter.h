/* Ofront 1.2 -xtspka */

#ifndef TextPrinter__h
#define TextPrinter__h

#include "SYSTEM.h"
#include "Fonts.h"
#include "Texts.h"

typedef
	struct TextPrinter_PrintMsg { /* Texts_ElemMsg */
		BOOLEAN prepare;
		LONGINT indent;
		Fonts_Font fnt;
		SHORTINT col;
		LONGINT pos;
		INTEGER X0, Y0, pno;
	} TextPrinter_PrintMsg;



import LONGINT *TextPrinter_PrintMsg__typ;

import LONGINT TextPrinter_DX (SHORTINT fno, CHAR ch);
import Fonts_Font TextPrinter_Font (SHORTINT fno);
import SHORTINT TextPrinter_FontNo (Fonts_Font fnt);
import void TextPrinter_Get (SHORTINT fno, CHAR ch, LONGINT *dx, LONGINT *x, LONGINT *y, LONGINT *w, LONGINT *h);
import void TextPrinter_GetChar (SHORTINT fno, LONGINT targetUnit, CHAR ch, LONGINT *pdx, INTEGER *dx, INTEGER *x, INTEGER *y, INTEGER *w, INTEGER *h, LONGINT *pat);
import void TextPrinter_InitFonts (void);
import void TextPrinter_PlaceBody (INTEGER bodyX, INTEGER bodyY, INTEGER bodyW, INTEGER bodyH, Texts_Text T, LONGINT *pos, INTEGER pno, BOOLEAN place);
import void TextPrinter_PlaceHeader (INTEGER headerX, INTEGER headerY, INTEGER headerW, INTEGER pno, Fonts_Font fnt, CHAR *header, LONGINT header__len, BOOLEAN alt);
import void TextPrinter_PrintDraft (Texts_Text t, CHAR *header, LONGINT header__len, INTEGER copies);
import void *TextPrinter__init(void);


#endif
