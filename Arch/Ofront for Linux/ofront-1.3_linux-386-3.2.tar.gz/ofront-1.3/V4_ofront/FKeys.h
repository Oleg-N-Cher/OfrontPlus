/* Ofront 1.2 -xtspka */

#ifndef FKeys__h
#define FKeys__h

#include "SYSTEM.h"
#include "Modules.h"




import void FKeys_Get (INTEGER n, Modules_Command *cmd);
import void FKeys_InternationalKey (void);
import void FKeys_Set (INTEGER n, Modules_Command cmd);
import void FKeys_SetCommand (void);
import void *FKeys__init(void);


#endif
