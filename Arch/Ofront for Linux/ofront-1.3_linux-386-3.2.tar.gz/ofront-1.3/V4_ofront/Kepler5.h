/* Ofront 1.2 -xtspka */

#ifndef Kepler5__h
#define Kepler5__h

#include "SYSTEM.h"
#include "KeplerGraphs.h"
#include "KeplerPorts.h"

typedef
	struct Kepler5_StarDesc *Kepler5_FocusStar;

typedef
	struct Kepler5_StarDesc2 *Kepler5_FocusStar2;

typedef
	struct Kepler5_PlanetDesc *Kepler5_Planet;

typedef
	struct Kepler5_PlanetDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler5_PlanetDesc;

import void Kepler5_Planet_Draw (Kepler5_Planet self, KeplerPorts_Port F);

typedef
	struct Kepler5_SelStarDesc *Kepler5_SelStar;

typedef
	struct Kepler5_SelStarDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler5_SelStarDesc;

import void Kepler5_SelStar_Draw (Kepler5_SelStar self, KeplerPorts_Port F);

typedef
	struct Kepler5_StarDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler5_StarDesc;

import void Kepler5_FocusStar_Draw (Kepler5_FocusStar self, KeplerPorts_Port F);

typedef
	struct Kepler5_StarDesc2 { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler5_StarDesc2;

import void Kepler5_FocusStar2_Draw (Kepler5_FocusStar2 self, KeplerPorts_Port F);



import LONGINT *Kepler5_StarDesc__typ;
import LONGINT *Kepler5_StarDesc2__typ;
import LONGINT *Kepler5_SelStarDesc__typ;
import LONGINT *Kepler5_PlanetDesc__typ;

import void Kepler5_NewFocusStar (void);
import void Kepler5_NewFocusStar2 (void);
import void Kepler5_NewPlanet (void);
import void Kepler5_NewSelStar (void);
import void *Kepler5__init(void);


#endif
