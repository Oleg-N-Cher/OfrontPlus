/* Ofront 1.2 -xtspka */

#ifndef PopupElems__h
#define PopupElems__h

#include "SYSTEM.h"




import void PopupElems_Alloc (void);
import void PopupElems_Insert (void);
import void PopupElems_InsertMenu (void);
import void PopupElems_Toggle (void);
import void PopupElems_Update (void);
import void *PopupElems__init(void);


#endif
