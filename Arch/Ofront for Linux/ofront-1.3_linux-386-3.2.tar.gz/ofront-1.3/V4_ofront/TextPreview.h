/* Ofront 1.2 -xtspka */

#ifndef TextPreview__h
#define TextPreview__h

#include "SYSTEM.h"




import void TextPreview_PageCount (void);
import void TextPreview_Paginate (void);
import void TextPreview_Synch (void);
import void TextPreview_This (void);
import void *TextPreview__init(void);


#endif
