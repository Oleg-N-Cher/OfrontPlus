/* Ofront 1.2 -xtspka */

#ifndef AsciiCoder__h
#define AsciiCoder__h

#include "SYSTEM.h"
#include "Files.h"
#include "Texts.h"




import void AsciiCoder_Code (Files_File from, Texts_Text to);
import void AsciiCoder_CodeFiles (void);
import void AsciiCoder_CodeText (void);
import void AsciiCoder_Compress (Files_File src, Files_File dest);
import void AsciiCoder_Decode (Texts_Text from, LONGINT *pos, Files_File to, BOOLEAN *ok);
import void AsciiCoder_DecodeFiles (void);
import void AsciiCoder_DecodeText (void);
import void AsciiCoder_Expand (Files_File src, Files_File dest);
import void *AsciiCoder__init(void);


#endif
