/* Ofront 1.2 -xtspka */

#ifndef Edit__h
#define Edit__h

#include "SYSTEM.h"




import void Edit_ChangeBackgroundColor (void);
import void Edit_ChangeColor (void);
import void Edit_ChangeFont (void);
import void Edit_ChangeOffset (void);
import void Edit_ClearReplaceBuffer (void);
import void Edit_Get (void);
import void Edit_InsertParc (void);
import void Edit_Locate (void);
import void Edit_Open (void);
import void Edit_Parcs (void);
import void Edit_Print (void);
import void Edit_Recall (void);
import void Edit_Replace (void);
import void Edit_ReplaceAll (void);
import void Edit_Search (void);
import void Edit_Set (void);
import void Edit_Show (void);
import void Edit_Store (void);
import void *Edit__init(void);


#endif
