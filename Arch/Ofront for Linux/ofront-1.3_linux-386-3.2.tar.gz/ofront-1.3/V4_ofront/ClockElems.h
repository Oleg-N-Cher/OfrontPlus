/* Ofront 1.2 -xtspka */

#ifndef ClockElems__h
#define ClockElems__h

#include "SYSTEM.h"




import void ClockElems_Insert (void);
import void ClockElems_New (void);
import void *ClockElems__init(void);


#endif
