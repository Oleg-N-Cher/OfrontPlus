/* Ofront 1.2 -xtspka */

#ifndef Input__h
#define Input__h

#include "SYSTEM.h"


import LONGINT Input_TimeUnit;


import INTEGER Input_Available (void);
import void Input_Mouse (SET *keys, INTEGER *x, INTEGER *y);
import void Input_Read (CHAR *ch);
import void Input_SetMouseLimits (INTEGER w, INTEGER h);
import LONGINT Input_Time (void);
import void *Input__init(void);


#endif
