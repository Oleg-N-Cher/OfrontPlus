/* Ofront 1.2 -xtspka */

#ifndef Oberon__h
#define Oberon__h

#include "SYSTEM.h"
#include "Display.h"
#include "Fonts.h"
#include "Texts.h"
#include "Viewers.h"

typedef
	struct Oberon_ControlMsg { /* Display_FrameMsg */
		INTEGER id, X, Y;
	} Oberon_ControlMsg;

typedef
	struct Oberon_CopyMsg { /* Display_FrameMsg */
		Display_Frame F;
	} Oberon_CopyMsg;

typedef
	struct Oberon_CopyOverMsg { /* Display_FrameMsg */
		Texts_Text text;
		LONGINT beg, end;
	} Oberon_CopyOverMsg;

typedef
	void (*Oberon_Painter)(INTEGER, INTEGER);

typedef
	struct Oberon_Marker {
		Oberon_Painter Fade, Draw;
	} Oberon_Marker;

typedef
	struct Oberon_Cursor {
		Oberon_Marker marker;
		BOOLEAN on;
		INTEGER X, Y;
	} Oberon_Cursor;

typedef
	void (*Oberon_Handler)(void);

typedef
	struct Oberon_InputMsg { /* Display_FrameMsg */
		INTEGER id;
		SET keys;
		INTEGER X, Y;
		CHAR ch;
		Fonts_Font fnt;
		SHORTINT col, voff;
	} Oberon_InputMsg;

typedef
	struct Oberon_ParRec *Oberon_ParList;

typedef
	struct Oberon_ParRec {
		Viewers_Viewer vwr;
		Display_Frame frame;
		Texts_Text text;
		LONGINT pos;
	} Oberon_ParRec;

typedef
	struct Oberon_SelectionMsg { /* Display_FrameMsg */
		LONGINT time;
		Texts_Text text;
		LONGINT beg, end;
	} Oberon_SelectionMsg;

typedef
	struct Oberon_TaskDesc *Oberon_Task;

typedef
	struct Oberon_TaskDesc {
		LONGINT _prvt0;
		BOOLEAN safe;
		LONGINT time;
		Oberon_Handler handle;
	} Oberon_TaskDesc;


import CHAR Oberon_User[12];
import Oberon_Marker Oberon_Arrow, Oberon_Star;
import Oberon_Cursor Oberon_Mouse, Oberon_Pointer;
import Viewers_Viewer Oberon_FocusViewer;
import Texts_Text Oberon_Log;
import Oberon_ParList Oberon_Par;
import Oberon_Task Oberon_CurTask;
import Fonts_Font Oberon_CurFnt;
import SHORTINT Oberon_CurCol, Oberon_CurOff;
import LONGINT Oberon_Password;

import LONGINT *Oberon_Marker__typ;
import LONGINT *Oberon_Cursor__typ;
import LONGINT *Oberon_ParRec__typ;
import LONGINT *Oberon_InputMsg__typ;
import LONGINT *Oberon_SelectionMsg__typ;
import LONGINT *Oberon_ControlMsg__typ;
import LONGINT *Oberon_CopyOverMsg__typ;
import LONGINT *Oberon_CopyMsg__typ;
import LONGINT *Oberon_TaskDesc__typ;

import void Oberon_AllocateSystemViewer (INTEGER DX, INTEGER *X, INTEGER *Y);
import void Oberon_AllocateUserViewer (INTEGER DX, INTEGER *X, INTEGER *Y);
import void Oberon_Call (CHAR *name, LONGINT name__len, Oberon_ParList par, BOOLEAN new, INTEGER *res);
import void Oberon_Collect (INTEGER count);
import INTEGER Oberon_DisplayHeight (INTEGER X);
import INTEGER Oberon_DisplayWidth (INTEGER X);
import void Oberon_DrawCursor (Oberon_Cursor *c, LONGINT *c__typ, Oberon_Marker *m, LONGINT *m__typ, INTEGER X, INTEGER Y);
import void Oberon_FadeCursor (Oberon_Cursor *c, LONGINT *c__typ);
import void Oberon_GetClock (LONGINT *t, LONGINT *d);
import void Oberon_GetSelection (Texts_Text *text, LONGINT *beg, LONGINT *end, LONGINT *time);
import void Oberon_Install (Oberon_Task T);
import void Oberon_Loop (void);
import Viewers_Viewer Oberon_MarkedViewer (void);
import void Oberon_OpenCursor (Oberon_Cursor *c, LONGINT *c__typ);
import void Oberon_OpenDisplay (INTEGER UW, INTEGER SW, INTEGER H);
import void Oberon_OpenTrack (INTEGER X, INTEGER W);
import void Oberon_PassFocus (Viewers_Viewer V);
import void Oberon_Remove (Oberon_Task T);
import void Oberon_RemoveMarks (INTEGER X, INTEGER Y, INTEGER W, INTEGER H);
import void Oberon_SetClock (LONGINT t, LONGINT d);
import void Oberon_SetColor (SHORTINT col);
import void Oberon_SetFont (Fonts_Font fnt);
import void Oberon_SetOffset (SHORTINT voff);
import void Oberon_SetUser (CHAR *user, LONGINT user__len, CHAR *password, LONGINT password__len);
import INTEGER Oberon_SystemTrack (INTEGER X);
import LONGINT Oberon_Time (void);
import INTEGER Oberon_UserTrack (INTEGER X);
import void *Oberon__init(void);


#endif
