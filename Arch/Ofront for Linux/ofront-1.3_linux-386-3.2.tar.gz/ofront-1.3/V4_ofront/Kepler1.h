/* Ofront 1.2 -xtspka */

#ifndef Kepler1__h
#define Kepler1__h

#include "SYSTEM.h"
#include "Files.h"
#include "Fonts.h"
#include "KeplerFrames.h"
#include "KeplerGraphs.h"
#include "KeplerPorts.h"

typedef
	struct Kepler1_AttrDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		INTEGER width, a1, a2;
	} Kepler1_AttrDesc;

typedef
	Kepler1_AttrDesc *Kepler1_AttrLine;

import void Kepler1_AttrLine_Draw (Kepler1_AttrLine A, KeplerPorts_Port F);
import void Kepler1_AttrLine_Read (Kepler1_AttrLine A, Files_Rider *R, LONGINT *R__typ);
import void Kepler1_AttrLine_Write (Kepler1_AttrLine A, Files_Rider *R, LONGINT *R__typ);

typedef
	struct Kepler1_CircleDesc *Kepler1_Circle;

typedef
	struct Kepler1_CircleDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler1_CircleDesc;

import void Kepler1_Circle_Draw (Kepler1_Circle C, KeplerPorts_Port F);

typedef
	struct Kepler1_EllipseDesc *Kepler1_Ellipse;

typedef
	struct Kepler1_EllipseDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler1_EllipseDesc;

import void Kepler1_Ellipse_Draw (Kepler1_Ellipse E, KeplerPorts_Port F);

typedef
	struct Kepler1_H90ShapeDesc *Kepler1_H90Shape;

typedef
	struct Kepler1_H90ShapeDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler1_H90ShapeDesc;

import void Kepler1_H90Shape_Draw (Kepler1_H90Shape self, KeplerPorts_Port F);

typedef
	struct Kepler1_HShapeDesc *Kepler1_HShape;

typedef
	struct Kepler1_HShapeDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler1_HShapeDesc;

import void Kepler1_HShape_Draw (Kepler1_HShape self, KeplerPorts_Port F);

typedef
	struct Kepler1_LineDesc *Kepler1_Line;

typedef
	struct Kepler1_LineDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler1_LineDesc;

import void Kepler1_Line_Draw (Kepler1_Line L, KeplerPorts_Port F);

typedef
	struct Kepler1_RectangleDesc *Kepler1_Rectangle;

typedef
	struct Kepler1_RectangleDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler1_RectangleDesc;

import void Kepler1_Rectangle_Draw (Kepler1_Rectangle R, KeplerPorts_Port F);

typedef
	struct Kepler1_StringDesc *Kepler1_String;

typedef
	struct Kepler1_StringDesc { /* KeplerFrames_CaptionDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		CHAR s[128];
		Fonts_Font fnt;
		SHORTINT align;
	} Kepler1_StringDesc;

typedef
	struct Kepler1_TextureDesc *Kepler1_Texture;

typedef
	struct Kepler1_TextureDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		INTEGER pat;
	} Kepler1_TextureDesc;

import void Kepler1_Texture_Draw (Kepler1_Texture T, KeplerPorts_Port F);
import void Kepler1_Texture_Read (Kepler1_Texture T, Files_Rider *R, LONGINT *R__typ);
import void Kepler1_Texture_Write (Kepler1_Texture T, Files_Rider *R, LONGINT *R__typ);

typedef
	struct Kepler1_TriangleDesc *Kepler1_Triangle;

typedef
	struct Kepler1_TriangleDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		INTEGER pat;
	} Kepler1_TriangleDesc;

import void Kepler1_Triangle_Draw (Kepler1_Triangle T, KeplerPorts_Port F);
import void Kepler1_Triangle_Read (Kepler1_Triangle T, Files_Rider *R, LONGINT *R__typ);
import void Kepler1_Triangle_Write (Kepler1_Triangle T, Files_Rider *R, LONGINT *R__typ);



import LONGINT *Kepler1_RectangleDesc__typ;
import LONGINT *Kepler1_TextureDesc__typ;
import LONGINT *Kepler1_LineDesc__typ;
import LONGINT *Kepler1_CircleDesc__typ;
import LONGINT *Kepler1_EllipseDesc__typ;
import LONGINT *Kepler1_StringDesc__typ;
import LONGINT *Kepler1_HShapeDesc__typ;
import LONGINT *Kepler1_H90ShapeDesc__typ;
import LONGINT *Kepler1_AttrDesc__typ;
import LONGINT *Kepler1_TriangleDesc__typ;

import void Kepler1_ChangeAlign (void);
import void Kepler1_ChangeAttrLine (void);
import void Kepler1_ChangeFont (void);
import void Kepler1_GetAttrLine (void);
import void Kepler1_Line2AttrLine (void);
import void Kepler1_NewAttrLine (void);
import void Kepler1_NewCircle (void);
import void Kepler1_NewEllipse (void);
import void Kepler1_NewH90Shape (void);
import void Kepler1_NewHShape (void);
import void Kepler1_NewLine (void);
import void Kepler1_NewRectangle (void);
import void Kepler1_NewString (void);
import void Kepler1_NewTexture (void);
import void Kepler1_NewTriangle (void);
import void *Kepler1__init(void);


#endif
