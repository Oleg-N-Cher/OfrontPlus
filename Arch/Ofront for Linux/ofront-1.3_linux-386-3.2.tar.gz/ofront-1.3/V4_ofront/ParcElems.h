/* Ofront 1.2 -xtspka */

#ifndef ParcElems__h
#define ParcElems__h

#include "SYSTEM.h"
#include "Display.h"
#include "Files.h"
#include "TextFrames.h"
#include "Texts.h"

typedef
	struct ParcElems_StateMsg { /* Texts_ElemMsg */
		INTEGER id;
		LONGINT pos;
		TextFrames_Frame frame;
		Texts_Scanner par;
		Texts_Text log;
	} ParcElems_StateMsg;



import LONGINT *ParcElems_StateMsg__typ;

import void ParcElems_Alloc (void);
import void ParcElems_ChangedParc (TextFrames_Parc P, LONGINT beg);
import void ParcElems_CopyParc (TextFrames_Parc SP, TextFrames_Parc DP);
import void ParcElems_Draw (TextFrames_Parc P, Display_Frame F, SHORTINT col, INTEGER x0, INTEGER y0);
import void ParcElems_Edit (TextFrames_Parc P, TextFrames_Frame F, LONGINT pos, INTEGER x0, INTEGER y0, INTEGER x, INTEGER y, SET keysum);
import void ParcElems_GetAttr (TextFrames_Parc P, TextFrames_Frame F, Texts_Scanner *S, LONGINT *S__typ, Texts_Text log);
import void ParcElems_Handle (Texts_Elem E, Texts_ElemMsg *msg, LONGINT *msg__typ);
import void ParcElems_LoadParc (TextFrames_Parc P, Files_Rider *r, LONGINT *r__typ);
import void ParcElems_ParcExtent (Texts_Text T, LONGINT beg, LONGINT *end);
import void ParcElems_Prepare (TextFrames_Parc P, LONGINT indent, LONGINT unit);
import void ParcElems_SetAttr (TextFrames_Parc P, TextFrames_Frame F, LONGINT pos, Texts_Scanner *S, LONGINT *S__typ, Texts_Text log);
import void ParcElems_StoreParc (TextFrames_Parc P, Files_Rider *r, LONGINT *r__typ);
import void *ParcElems__init(void);


#endif
