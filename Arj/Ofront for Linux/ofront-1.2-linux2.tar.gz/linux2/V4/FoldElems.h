/* Ofront 1.2 -xtspka */

#ifndef FoldElems__h
#define FoldElems__h

#include "SYSTEM.h"
#include "Texts.h"

typedef
	BOOLEAN (*FoldElems_CheckProc)(Texts_Elem);

typedef
	struct FoldElems_ElemDesc *FoldElems_Elem;

typedef
	struct FoldElems_ElemDesc { /* Texts_ElemDesc */
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
		SHORTINT mode;
		Texts_Buffer hidden;
		BOOLEAN visible;
	} FoldElems_ElemDesc;

typedef
	struct FoldElems_PrepSwitchMsg { /* Texts_ElemMsg */
		char _prvt0[1];
	} FoldElems_PrepSwitchMsg;


import LONGINT FoldElems_elemW, FoldElems_elemH;

import LONGINT *FoldElems_ElemDesc__typ;
import LONGINT *FoldElems_PrepSwitchMsg__typ;

import void FoldElems_Collapse (void);
import void FoldElems_CollapseAll (Texts_Text t, SET modes);
import void FoldElems_Echo (Texts_Text t, BOOLEAN on);
import void FoldElems_Expand (void);
import void FoldElems_ExpandAll (Texts_Text t, LONGINT from, BOOLEAN temporal);
import void FoldElems_FindElem (Texts_Text t, LONGINT pos, FoldElems_CheckProc P, Texts_Elem *elem);
import void FoldElems_FoldHandler (Texts_Elem e, Texts_ElemMsg *m, LONGINT *m__typ);
import void FoldElems_Insert (void);
import void FoldElems_InsertCollapsed (void);
import void FoldElems_Marks (void);
import void FoldElems_New (void);
import void FoldElems_Restore (void);
import void FoldElems_Search (void);
import void FoldElems_Switch (FoldElems_Elem e);
import FoldElems_Elem FoldElems_Twin (FoldElems_Elem e);
import void *FoldElems__init(void);


#endif
