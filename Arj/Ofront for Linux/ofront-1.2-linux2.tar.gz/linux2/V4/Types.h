/* Ofront 1.2 -xtspka */

#ifndef Types__h
#define Types__h

#include "SYSTEM.h"
#include "Modules.h"

typedef
	struct Types_TypeDesc *Types_Type;

typedef
	struct Types_TypeDesc {
		char _prvt0[8];
		Modules_Module module;
		CHAR name[24];
		char _prvt1[72];
	} Types_TypeDesc;



import LONGINT *Types_TypeDesc__typ;

import Types_Type Types_BaseOf (Types_Type t, INTEGER level);
import INTEGER Types_LevelOf (Types_Type t);
import void Types_NewObj (SYSTEM_PTR *o, Types_Type t);
import Types_Type Types_This (Modules_Module mod, CHAR *name, LONGINT name__len);
import Types_Type Types_TypeOf (SYSTEM_PTR o);
import void *Types__init(void);


#endif
