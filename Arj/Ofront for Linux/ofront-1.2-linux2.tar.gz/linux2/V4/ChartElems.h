/* Ofront 1.2 -xtspka */

#ifndef ChartElems__h
#define ChartElems__h

#include "SYSTEM.h"




import void ChartElems_Alloc (void);
import void ChartElems_Insert (void);
import void *ChartElems__init(void);


#endif
