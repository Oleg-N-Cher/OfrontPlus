/* Ofront 1.2 -xtspka */

#ifndef KeplerGraphs__h
#define KeplerGraphs__h

#include "SYSTEM.h"
#include "Files.h"
#include "KeplerPorts.h"

typedef
	struct KeplerGraphs_ObjectDesc {
		char _prvt0[1];
	} KeplerGraphs_ObjectDesc;

typedef
	KeplerGraphs_ObjectDesc *KeplerGraphs_Object;

import void KeplerGraphs_Object_Draw (KeplerGraphs_Object self, KeplerPorts_Port P);
import void KeplerGraphs_Object_Read (KeplerGraphs_Object self, Files_Rider *R, LONGINT *R__typ);
import void KeplerGraphs_Object_Write (KeplerGraphs_Object self, Files_Rider *R, LONGINT *R__typ);
#define __KeplerGraphs_Object_Draw(self, P) __SEND(__TYPEOF(self), 0, void(*)(KeplerGraphs_Object, KeplerPorts_Port), (self, P))
#define __KeplerGraphs_Object_Read(self, R, R__typ) __SEND(__TYPEOF(self), 1, void(*)(KeplerGraphs_Object, Files_Rider*, LONGINT *), (self, R, R__typ))
#define __KeplerGraphs_Object_Write(self, R, R__typ) __SEND(__TYPEOF(self), 2, void(*)(KeplerGraphs_Object, Files_Rider*, LONGINT *), (self, R, R__typ))

typedef
	struct KeplerGraphs_StarDesc *KeplerGraphs_Star;

typedef
	struct KeplerGraphs_ConsDesc *KeplerGraphs_Constellation;

typedef
	struct KeplerGraphs_ConsDesc { /* KeplerGraphs_ObjectDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} KeplerGraphs_ConsDesc;

import void KeplerGraphs_Constellation_Read (KeplerGraphs_Constellation self, Files_Rider *R, LONGINT *R__typ);
import INTEGER KeplerGraphs_Constellation_State (KeplerGraphs_Constellation self);
import void KeplerGraphs_Constellation_Write (KeplerGraphs_Constellation self, Files_Rider *R, LONGINT *R__typ);
#define __KeplerGraphs_Constellation_State(self) __SEND(__TYPEOF(self), 3, INTEGER(*)(KeplerGraphs_Constellation), (self))

typedef
	struct KeplerGraphs_GraphDesc *KeplerGraphs_Graph;

typedef
	void (*KeplerGraphs_Notifier)(INTEGER, KeplerGraphs_Graph, KeplerGraphs_Object, KeplerPorts_Port);

typedef
	struct KeplerGraphs_GraphDesc { /* KeplerGraphs_ObjectDesc */
		KeplerGraphs_Constellation cons;
		char _prvt0[4];
		KeplerGraphs_Star stars;
		char _prvt1[4];
		LONGINT seltime;
		KeplerGraphs_Notifier notify;
	} KeplerGraphs_GraphDesc;

import void KeplerGraphs_Graph_All (KeplerGraphs_Graph G, INTEGER op);
import void KeplerGraphs_Graph_Append (KeplerGraphs_Graph G, KeplerGraphs_Object o);
import void KeplerGraphs_Graph_CopySelection (KeplerGraphs_Graph G, KeplerGraphs_Graph from, INTEGER dx, INTEGER dy);
import void KeplerGraphs_Graph_Delete (KeplerGraphs_Graph G, KeplerGraphs_Object o);
import void KeplerGraphs_Graph_DeleteSelection (KeplerGraphs_Graph G, INTEGER minstate);
import void KeplerGraphs_Graph_Draw (KeplerGraphs_Graph G, KeplerPorts_Port P);
import void KeplerGraphs_Graph_FlipSelection (KeplerGraphs_Graph G, KeplerGraphs_Star p);
import void KeplerGraphs_Graph_Insert (KeplerGraphs_Graph G, KeplerGraphs_Constellation c, KeplerGraphs_Constellation before);
import void KeplerGraphs_Graph_Move (KeplerGraphs_Graph G, KeplerGraphs_Star s, INTEGER dx, INTEGER dy);
import void KeplerGraphs_Graph_MoveSelection (KeplerGraphs_Graph G, INTEGER dx, INTEGER dy);
import void KeplerGraphs_Graph_Read (KeplerGraphs_Graph G, Files_Rider *R, LONGINT *R__typ);
import void KeplerGraphs_Graph_SendToBack (KeplerGraphs_Graph G, KeplerGraphs_Object o);
import void KeplerGraphs_Graph_Write (KeplerGraphs_Graph G, Files_Rider *R, LONGINT *R__typ);
import void KeplerGraphs_Graph_WriteSel (KeplerGraphs_Graph G, Files_Rider *R, LONGINT *R__typ);
#define __KeplerGraphs_Graph_All(G, op) __SEND(__TYPEOF(G), 3, void(*)(KeplerGraphs_Graph, INTEGER), (G, op))
#define __KeplerGraphs_Graph_Append(G, o) __SEND(__TYPEOF(G), 4, void(*)(KeplerGraphs_Graph, KeplerGraphs_Object), (G, o))
#define __KeplerGraphs_Graph_CopySelection(G, from, dx, dy) __SEND(__TYPEOF(G), 5, void(*)(KeplerGraphs_Graph, KeplerGraphs_Graph, INTEGER, INTEGER), (G, from, dx, dy))
#define __KeplerGraphs_Graph_Delete(G, o) __SEND(__TYPEOF(G), 6, void(*)(KeplerGraphs_Graph, KeplerGraphs_Object), (G, o))
#define __KeplerGraphs_Graph_DeleteSelection(G, minstate) __SEND(__TYPEOF(G), 7, void(*)(KeplerGraphs_Graph, INTEGER), (G, minstate))
#define __KeplerGraphs_Graph_FlipSelection(G, p) __SEND(__TYPEOF(G), 8, void(*)(KeplerGraphs_Graph, KeplerGraphs_Star), (G, p))
#define __KeplerGraphs_Graph_Insert(G, c, before) __SEND(__TYPEOF(G), 9, void(*)(KeplerGraphs_Graph, KeplerGraphs_Constellation, KeplerGraphs_Constellation), (G, c, before))
#define __KeplerGraphs_Graph_Move(G, s, dx, dy) __SEND(__TYPEOF(G), 10, void(*)(KeplerGraphs_Graph, KeplerGraphs_Star, INTEGER, INTEGER), (G, s, dx, dy))
#define __KeplerGraphs_Graph_MoveSelection(G, dx, dy) __SEND(__TYPEOF(G), 11, void(*)(KeplerGraphs_Graph, INTEGER, INTEGER), (G, dx, dy))
#define __KeplerGraphs_Graph_SendToBack(G, o) __SEND(__TYPEOF(G), 12, void(*)(KeplerGraphs_Graph, KeplerGraphs_Object), (G, o))
#define __KeplerGraphs_Graph_WriteSel(G, R, R__typ) __SEND(__TYPEOF(G), 13, void(*)(KeplerGraphs_Graph, Files_Rider*, LONGINT *), (G, R, R__typ))

typedef
	struct KeplerGraphs_PlanetDesc *KeplerGraphs_Planet;

typedef
	struct KeplerGraphs_StarDesc { /* KeplerGraphs_ObjectDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
	} KeplerGraphs_StarDesc;

import void KeplerGraphs_Star_Draw (KeplerGraphs_Star self, KeplerPorts_Port P);
import void KeplerGraphs_Star_Read (KeplerGraphs_Star self, Files_Rider *R, LONGINT *R__typ);
import void KeplerGraphs_Star_Write (KeplerGraphs_Star self, Files_Rider *R, LONGINT *R__typ);

typedef
	struct KeplerGraphs_PlanetDesc { /* KeplerGraphs_StarDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} KeplerGraphs_PlanetDesc;

import void KeplerGraphs_Planet_Calc (KeplerGraphs_Planet self);
import void KeplerGraphs_Planet_Draw (KeplerGraphs_Planet self, KeplerPorts_Port P);
import void KeplerGraphs_Planet_Read (KeplerGraphs_Planet self, Files_Rider *R, LONGINT *R__typ);
import void KeplerGraphs_Planet_Write (KeplerGraphs_Planet self, Files_Rider *R, LONGINT *R__typ);
#define __KeplerGraphs_Planet_Calc(self) __SEND(__TYPEOF(self), 3, void(*)(KeplerGraphs_Planet), (self))


import KeplerGraphs_Graph KeplerGraphs_loading;

import LONGINT *KeplerGraphs_ObjectDesc__typ;
import LONGINT *KeplerGraphs_StarDesc__typ;
import LONGINT *KeplerGraphs_ConsDesc__typ;
import LONGINT *KeplerGraphs_PlanetDesc__typ;
import LONGINT *KeplerGraphs_GraphDesc__typ;

import void KeplerGraphs_GetType (KeplerGraphs_Object o, CHAR *module, LONGINT module__len, CHAR *type, LONGINT type__len);
import KeplerGraphs_Graph KeplerGraphs_Old (CHAR *name, LONGINT name__len);
import void KeplerGraphs_ReadObj (Files_Rider *R, LONGINT *R__typ, KeplerGraphs_Object *x);
import void KeplerGraphs_Recall (void);
import void KeplerGraphs_Reset (void);
import void KeplerGraphs_WriteObj (Files_Rider *R, LONGINT *R__typ, KeplerGraphs_Object x);
import void *KeplerGraphs__init(void);


#endif
