/* Ofront 1.2 -xtspka */

#ifndef ErrorElems__h
#define ErrorElems__h

#include "SYSTEM.h"
#include "Display.h"
#include "Fonts.h"
#include "Texts.h"

typedef
	struct ErrorElems_ElemDesc *ErrorElems_Elem;

typedef
	struct ErrorElems_ElemDesc { /* Texts_ElemDesc */
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
		INTEGER err;
		CHAR msg[128];
		char _prvt2[1];
	} ErrorElems_ElemDesc;


import Fonts_Font ErrorElems_font;

import LONGINT *ErrorElems_ElemDesc__typ;

import void ErrorElems_Copy (ErrorElems_Elem SE, ErrorElems_Elem DE);
import void ErrorElems_Delete (ErrorElems_Elem E, LONGINT pos);
import void ErrorElems_Disp (ErrorElems_Elem E, Display_Frame F, SHORTINT col, Fonts_Font fnt, INTEGER x0, INTEGER y0);
import void ErrorElems_Edit (ErrorElems_Elem E, LONGINT pos, INTEGER x0, INTEGER y0, INTEGER x, INTEGER y, SET keysum);
import void ErrorElems_Expand (ErrorElems_Elem E, LONGINT pos);
import void ErrorElems_Handle (Texts_Elem E, Texts_ElemMsg *msg, LONGINT *msg__typ);
import void ErrorElems_InsertAt (Texts_Text T, LONGINT pos, INTEGER err);
import void ErrorElems_LocateNext (void);
import void ErrorElems_Mark (void);
import void ErrorElems_Prepare (ErrorElems_Elem E, Fonts_Font fnt, INTEGER *voff);
import void ErrorElems_Print (ErrorElems_Elem E, INTEGER x0, INTEGER y0);
import void ErrorElems_Reduce (ErrorElems_Elem E, LONGINT pos);
import void ErrorElems_ShowErrMsg (ErrorElems_Elem E, Display_Frame F, SHORTINT col, INTEGER x0, INTEGER y0, INTEGER dw);
import void ErrorElems_Unmark (void);
import void *ErrorElems__init(void);


#endif
