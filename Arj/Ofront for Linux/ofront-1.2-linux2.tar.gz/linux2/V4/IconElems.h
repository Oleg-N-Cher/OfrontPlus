/* Ofront 1.2 -xtspka */

#ifndef IconElems__h
#define IconElems__h

#include "SYSTEM.h"




import void IconElems_Insert (void);
import void IconElems_New (void);
import void IconElems_Stop (void);
import void *IconElems__init(void);


#endif
