/* Ofront 1.2 -xtspka */

#ifndef Kepler8__h
#define Kepler8__h

#include "SYSTEM.h"
#include "Files.h"
#include "KeplerGraphs.h"
#include "KeplerPorts.h"

typedef
	struct Kepler8_AttrRectDesc *Kepler8_AttrRect;

typedef
	struct Kepler8_AttrRectDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		INTEGER texture, lineWidth, shadow, shadowWidth, corner;
	} Kepler8_AttrRectDesc;

import void Kepler8_AttrRect_Draw (Kepler8_AttrRect self, KeplerPorts_Port f);
import void Kepler8_AttrRect_Read (Kepler8_AttrRect self, Files_Rider *r, LONGINT *r__typ);
import void Kepler8_AttrRect_Write (Kepler8_AttrRect self, Files_Rider *r, LONGINT *r__typ);

typedef
	struct Kepler8_CircleIntersectDesc *Kepler8_CircleIntersect;

typedef
	struct Kepler8_CircleIntersectDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler8_CircleIntersectDesc;

import void Kepler8_CircleIntersect_Calc (Kepler8_CircleIntersect self);

typedef
	struct Kepler8_EllipIntersectDesc *Kepler8_EllipIntersect;

typedef
	struct Kepler8_EllipIntersectDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler8_EllipIntersectDesc;

import void Kepler8_EllipIntersect_Calc (Kepler8_EllipIntersect self);

typedef
	struct Kepler8_FilledCircleDesc *Kepler8_FilledCircle;

typedef
	struct Kepler8_FilledCircleDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		INTEGER texture;
	} Kepler8_FilledCircleDesc;

import void Kepler8_FilledCircle_Draw (Kepler8_FilledCircle self, KeplerPorts_Port f);
import void Kepler8_FilledCircle_Read (Kepler8_FilledCircle self, Files_Rider *r, LONGINT *r__typ);
import void Kepler8_FilledCircle_Write (Kepler8_FilledCircle self, Files_Rider *r, LONGINT *r__typ);

typedef
	struct Kepler8_RectIntersectDesc *Kepler8_RectIntersect;

typedef
	struct Kepler8_RectIntersectDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler8_RectIntersectDesc;

import void Kepler8_RectIntersect_Calc (Kepler8_RectIntersect self);



import LONGINT *Kepler8_RectIntersectDesc__typ;
import LONGINT *Kepler8_CircleIntersectDesc__typ;
import LONGINT *Kepler8_EllipIntersectDesc__typ;
import LONGINT *Kepler8_AttrRectDesc__typ;
import LONGINT *Kepler8_FilledCircleDesc__typ;

import void Kepler8_ChangeAttrRect (void);
import void Kepler8_GetAttrRect (void);
import void Kepler8_NewAttrRect (void);
import void Kepler8_NewCircleIntersect (void);
import void Kepler8_NewEllipseIntersect (void);
import void Kepler8_NewFilledCircle (void);
import void Kepler8_NewRectIntersect (void);
import void *Kepler8__init(void);


#endif
