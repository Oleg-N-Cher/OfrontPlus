/* Ofront 1.2 -xtspka */

#ifndef Out__h
#define Out__h

#include "SYSTEM.h"




import void Out_Char (CHAR ch);
import void Out_Int (LONGINT i, LONGINT n);
import void Out_Ln (void);
import void Out_LongReal (LONGREAL x, INTEGER n);
import void Out_Open (void);
import void Out_Real (REAL x, INTEGER n);
import void Out_String (CHAR *str, LONGINT str__len);
import void *Out__init(void);


#endif
