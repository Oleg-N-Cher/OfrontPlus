/* Ofront 1.2 -xtspka */

#ifndef StyleElems__h
#define StyleElems__h

#include "SYSTEM.h"
#include "Display.h"
#include "Files.h"
#include "Fonts.h"
#include "TextFrames.h"
#include "Texts.h"

typedef
	CHAR StyleElems_Name[32];

typedef
	struct StyleElems_ParcDesc *StyleElems_Parc;

typedef
	struct StyleElems_ParcDesc { /* TextFrames_ParcDesc */
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
		LONGINT left, first, width, lead, lsp, dsr;
		SET opts;
		INTEGER nofTabs;
		LONGINT tab[32];
		StyleElems_Name name;
		char _prvt2[4];
	} StyleElems_ParcDesc;

typedef
	struct StyleElems_UpdateMsg { /* Texts_ElemMsg */
		INTEGER id;
		LONGINT pos;
		StyleElems_Name name, newName;
		StyleElems_Parc parc;
	} StyleElems_UpdateMsg;


import Fonts_Font StyleElems_font;

import LONGINT *StyleElems_ParcDesc__typ;
import LONGINT *StyleElems_UpdateMsg__typ;

import void StyleElems_Alloc (void);
import void StyleElems_Broadcast (Texts_Text T, StyleElems_UpdateMsg *msg, LONGINT *msg__typ);
import void StyleElems_ChangeName (StyleElems_Parc P, CHAR *name, LONGINT name__len, BOOLEAN *synched);
import void StyleElems_ChangeSetting (StyleElems_Parc P);
import void StyleElems_Copy (StyleElems_Parc SP, StyleElems_Parc DP);
import void StyleElems_Draw (StyleElems_Parc P, Display_Frame F, SHORTINT col, INTEGER x0, INTEGER y0);
import void StyleElems_Edit (StyleElems_Parc P, TextFrames_Frame F, LONGINT pos, INTEGER x0, INTEGER y0, INTEGER x, INTEGER y, SET keysum);
import void StyleElems_Handle (Texts_Elem E, Texts_ElemMsg *msg, LONGINT *msg__typ);
import void StyleElems_Insert (void);
import void StyleElems_Load (StyleElems_Parc P, Files_Rider *r, LONGINT *r__typ);
import void StyleElems_Prepare (StyleElems_Parc P, LONGINT indent, LONGINT unit);
import void StyleElems_Rename (void);
import void StyleElems_RenameAll (void);
import void StyleElems_Search (Texts_Text T, StyleElems_Name name, StyleElems_Parc *P);
import void StyleElems_SetAttr (StyleElems_Parc P, TextFrames_Frame F, Texts_Scanner *S, LONGINT *S__typ, Texts_Text log);
import void StyleElems_Store (StyleElems_Parc P, Files_Rider *r, LONGINT *r__typ);
import void StyleElems_Synch (StyleElems_Parc P, BOOLEAN *synched);
import void *StyleElems__init(void);


#endif
