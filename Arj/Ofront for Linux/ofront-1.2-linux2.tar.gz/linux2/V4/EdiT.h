/* Ofront 1.2 -xtspka */

#ifndef EdiT__h
#define EdiT__h

#include "SYSTEM.h"
#include "Display.h"




import void EdiT_Grep (void);
import void EdiT_Handle (Display_Frame F, Display_FrameMsg *M, LONGINT *M__typ);
import void EdiT_LocateLine (void);
import void EdiT_Match (void);
import void EdiT_Open (void);
import void EdiT_SearchDiff (void);
import void EdiT_Show (void);
import void EdiT_StoreAscii (void);
import void EdiT_StoreDosAscii (void);
import void EdiT_StoreMacAscii (void);
import void *EdiT__init(void);


#endif
