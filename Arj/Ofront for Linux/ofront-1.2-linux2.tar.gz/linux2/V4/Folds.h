/* Ofront 1.2 -xtspka */

#ifndef Folds__h
#define Folds__h

#include "SYSTEM.h"




import void Folds_Compile (void);
import void Folds_SetProfile (void);
import void Folds_ShowError (void);
import void *Folds__init(void);


#endif
