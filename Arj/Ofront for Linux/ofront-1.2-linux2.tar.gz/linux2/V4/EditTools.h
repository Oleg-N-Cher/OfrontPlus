/* Ofront 1.2 -xtspka */

#ifndef EditTools__h
#define EditTools__h

#include "SYSTEM.h"
#include "TextFrames.h"
#include "Texts.h"
#include "Viewers.h"




import void EditTools_Change (void);
import void EditTools_ChangeFamily (void);
import void EditTools_ChangeFont (Texts_Text T, LONGINT beg, LONGINT end, CHAR *old, LONGINT old__len, CHAR *new, LONGINT new__len);
import void EditTools_ChangeFontFamily (Texts_Text T, LONGINT beg, LONGINT end, CHAR *old, LONGINT old__len, CHAR *new, LONGINT new__len);
import void EditTools_ChangeFontSize (Texts_Text T, LONGINT beg, LONGINT end, INTEGER old, INTEGER new);
import void EditTools_ChangeFontStyle (Texts_Text T, LONGINT beg, LONGINT end, CHAR old, CHAR new);
import void EditTools_ChangeSize (void);
import void EditTools_ChangeStyle (void);
import void EditTools_Cleanup (void);
import void EditTools_ConvertToAscii (Texts_Text T, LONGINT beg, LONGINT end);
import void EditTools_Count (Texts_Text T, LONGINT beg, LONGINT end, LONGINT *wc, LONGINT *pc, LONGINT *ec);
import void EditTools_DeleteElems (Texts_Text T, LONGINT beg, LONGINT end);
import void EditTools_DeleteMonsters (Texts_Text T, LONGINT monsterW, LONGINT monsterH, LONGINT *mc);
import void EditTools_GetAttr (void);
import void EditTools_IncFontSize (Texts_Text T, LONGINT beg, LONGINT end, INTEGER delta);
import void EditTools_IncSize (void);
import void EditTools_InsertCR (void);
import void EditTools_LocateLine (void);
import void EditTools_Refresh (void);
import void EditTools_RemoveCR (void);
import void EditTools_RemoveElems (void);
import void EditTools_SearchAttr (void);
import void EditTools_SearchDiff (void);
import TextFrames_Frame EditTools_SelectedFrame (void);
import void EditTools_ShowAliens (void);
import void EditTools_StoreAscii (void);
import void EditTools_ToAscii (void);
import void EditTools_UnmarkMenu (Viewers_Viewer V);
import void EditTools_Words (void);
import void *EditTools__init(void);


#endif
